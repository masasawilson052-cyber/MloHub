import React from 'react';
import { Redirect } from 'expo-router';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../db/types';
import AuthLandingScreen from './auth/index';

export default function RootIndex() {
  const { isAuthenticated, currentRole, user } = useAuth();

  // Statically and dynamically render AuthLandingScreen on root when not authenticated
  if (!isAuthenticated) {
    return <AuthLandingScreen />;
  }

  const isRestaurant =
    currentRole === UserRole.RESTAURANT_OWNER ||
    currentRole === UserRole.RESTAURANT_STAFF ||
    user?.role === UserRole.RESTAURANT_OWNER ||
    user?.activeRole === UserRole.RESTAURANT_OWNER;

  if (isRestaurant) {
    return <Redirect href="/restaurant-portal" />;
  }

  return <Redirect href="/(tabs)" />;
}
