import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Colors } from '../constants/theme';
import { DbProvider, useMloHubDB } from '../context/DbContext';
import { AuthProvider, useAuth } from '../context/AuthContext';
import { LanguageProvider } from '../context/LanguageContext';
import { NotificationProvider } from '../context/NotificationContext';
import { CartProvider } from '../context/CartContext';
import { UserRole } from '../db/types';

function RootNavigationLayout() {
  const router = useRouter();
  const segments = useSegments();
  const { isReady, hasCompletedOnboarding } = useMloHubDB();
  const { isAuthLoading, isAuthenticated, currentRole, activeWorkspace, user } = useAuth();

  useEffect(() => {
    if (!isReady || isAuthLoading) return;

    const inOnboarding = segments[0] === 'onboarding';
    const inAuth = segments[0] === 'auth';
    const inRestaurantPortal = segments[0] === 'restaurant-portal';
    const inTabs = segments[0] === '(tabs)';

    if (!hasCompletedOnboarding && !inOnboarding) {
      router.replace('/onboarding');
      return;
    }

    if (isAuthenticated) {
      // Respect active workspace: if owner switched to customer workspace, allow customer tabs
      if (activeWorkspace === 'RESTAURANT_OWNER' && inAuth) {
        router.replace('/restaurant-portal');
        return;
      }

      if ((activeWorkspace === 'CUSTOMER' || !activeWorkspace) && inAuth) {
        router.replace('/(tabs)');
        return;
      }
    } else {
      // Unauthenticated users start at login / signup
      const inAdmin = segments[0] === 'admin';
      if (!inAuth && !inOnboarding && !inAdmin) {
        router.replace('/auth');
        return;
      }
    }
  }, [isReady, isAuthLoading, hasCompletedOnboarding, isAuthenticated, currentRole, activeWorkspace, user, segments]);

  return (
    <>
      <StatusBar style="dark" backgroundColor={Colors.background} />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: Colors.background },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="auth" options={{ headerShown: false }} />
        <Stack.Screen
          name="onboarding"
          options={{
            headerShown: false,
            animation: 'fade',
          }}
        />
        <Stack.Screen
          name="restaurant-portal/index"
          options={{
            headerShown: false,
            animation: 'slide_from_right',
          }}
        />
        <Stack.Screen
          name="admin/index"
          options={{
            headerShown: false,
            animation: 'slide_from_right',
          }}
        />
        <Stack.Screen
          name="notifications/index"
          options={{
            headerShown: false,
            animation: 'slide_from_right',
          }}
        />
        <Stack.Screen
          name="notifications/settings"
          options={{
            headerShown: false,
            animation: 'slide_from_right',
          }}
        />
        <Stack.Screen
          name="restaurant/[id]"
          options={{
            presentation: 'modal',
            headerShown: false,
          }}
        />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <DbProvider>
        <AuthProvider>
          <LanguageProvider>
            <NotificationProvider>
              <CartProvider>
                <RootNavigationLayout />
              </CartProvider>
            </NotificationProvider>
          </LanguageProvider>
        </AuthProvider>
      </DbProvider>
    </SafeAreaProvider>
  );
}
