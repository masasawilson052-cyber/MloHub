import React, { useState } from 'react';
import {
  ScrollView,
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { Colors, Spacing, Radii, Shadows } from '../../constants/theme';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { PriceText } from '../../components/ui/PriceText';
import { EmptyState } from '../../components/ui/EmptyState';
import { FloatingCartButton } from '../../components/cart/FloatingCartButton';
import { CartDrawer } from '../../components/cart/CartDrawer';
import { OrderReviewModal } from '../../components/checkout/OrderReviewModal';

export default function CustomMealScreen() {
  const { t, language } = useLanguage();
  const { width } = useWindowDimensions();
  const isLargeScreen = width > 768;
  const { user } = useAuth();
  const { addToCart, isCartOpen, setIsCartOpen } = useCart();
  const [isOrderReviewOpen, setIsOrderReviewOpen] = useState(false);

  // Flow Step: 'REQUEST' | 'QUOTES'
  const [activeTab, setActiveTab] = useState<'REQUEST' | 'QUOTES'>('REQUEST');

  // Form Fields
  const [dishTitle, setDishTitle] = useState('');
  const [description, setDescription] = useState('');
  const [budgetTzs, setBudgetTzs] = useState('');
  const [servings, setServings] = useState('1');
  const [desiredTime, setDesiredTime] = useState('');
  const [location, setLocation] = useState(user?.location || '');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Chef Quotes Received
  const [quotes, setQuotes] = useState<
    {
      id: string;
      restaurantName: string;
      rating: number;
      reviews: number;
      priceTzs: number;
      prepTimeMinutes: number;
      message: string;
      inclusions: string;
      status: string;
    }[]
  >([]);

  const handleSubmitRequest = () => {
    if (!dishTitle.trim()) {
      Alert.alert('Missing Dish Title', 'Please specify what dish you would like prepared.');
      return;
    }
    if (!location.trim()) {
      Alert.alert(
        language === 'sw' ? 'Eneo Linahitajika' : 'Location Required',
        language === 'sw' ? 'Tafadhali ingiza eneo lako la uwasilishaji.' : 'Please enter your delivery neighborhood.'
      );
      return;
    }
    setIsSubmitted(true);
    setActiveTab('QUOTES');
    Alert.alert(
      language === 'sw' ? 'Ombi Limetumwa!' : 'Meal Request Dispatched!',
      language === 'sw'
        ? 'Migahawa iliyo karibu inapokea maelezo yako na inakuandalia ofa za bei.'
        : 'Nearby specialty kitchens are reviewing your custom meal request and submitting quotes.'
    );
  };

  const handleAcceptQuote = (quote: typeof quotes[0]) => {
    addToCart({
      dishId: `custom-${quote.id}`,
      dishName: `Custom: ${dishTitle}`,
      restaurantId: 'mama-amina-mikocheni',
      restaurantName: quote.restaurantName,
      priceTzs: quote.priceTzs,
      notes: `${servings} servings. ${description}`,
    });
    setIsCartOpen(true);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          isLargeScreen && styles.largeScreenContainer,
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.eyebrow}>
            {language === 'sw' ? 'MIPANGO YA CHAKULA MAALUM' : 'BESPOKE CATERING & MEALS'}
          </Text>
          <Text style={styles.title}>
            {language === 'sw' ? 'Omba Mlo Maalum' : 'Request a Custom Meal'}
          </Text>
          <Text style={styles.subtitle}>
            {language === 'sw'
              ? 'Eleza kile unachotaka kuandaliwa na upate ofa za bei kutoka kwa wapishi wa karibu.'
              : 'Specify what you want prepared and receive custom price quotes from nearby kitchens.'}
          </Text>
        </View>

        {/* Tab Switcher */}
        <View style={styles.tabRow}>
          <TouchableOpacity
            style={[styles.tabBtn, activeTab === 'REQUEST' && styles.tabBtnActive]}
            onPress={() => setActiveTab('REQUEST')}
            accessible={true}
            accessibilityRole="tab"
            accessibilityState={{ selected: activeTab === 'REQUEST' }}
          >
            <Text style={[styles.tabText, activeTab === 'REQUEST' && styles.tabTextActive]}>
              1. Meal Request
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tabBtn, activeTab === 'QUOTES' && styles.tabBtnActive]}
            onPress={() => setActiveTab('QUOTES')}
            accessible={true}
            accessibilityRole="tab"
            accessibilityState={{ selected: activeTab === 'QUOTES' }}
          >
            <Text style={[styles.tabText, activeTab === 'QUOTES' && styles.tabTextActive]}>
              2. Chef Quotes ({quotes.length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* TAB 1: MEAL REQUEST FORM */}
        {activeTab === 'REQUEST' && (
          <View style={styles.formCard}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>What do you want prepared?</Text>
              <TextInput
                style={styles.textInput}
                value={dishTitle}
                onChangeText={setDishTitle}
                placeholder="e.g. Swahili Coconut Fish Curry with Chapati"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Special Instructions & Ingredients</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={description}
                onChangeText={setDescription}
                multiline={true}
                numberOfLines={3}
                placeholder="Include diet preferences, spice level, or special sauces..."
              />
            </View>

            <View style={styles.rowTwoCols}>
              <View style={[styles.inputGroup, { flex: 1, marginRight: Spacing.sm }]}>
                <Text style={styles.inputLabel}>Target Budget (TZS)</Text>
                <TextInput
                  style={styles.textInput}
                  value={budgetTzs}
                  onChangeText={setBudgetTzs}
                  keyboardType="numeric"
                  placeholder="15000"
                />
              </View>

              <View style={[styles.inputGroup, { flex: 1 }]}>
                <Text style={styles.inputLabel}>Servings (People)</Text>
                <TextInput
                  style={styles.textInput}
                  value={servings}
                  onChangeText={setServings}
                  keyboardType="numeric"
                  placeholder="4"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Desired Time / Date</Text>
              <TextInput
                style={styles.textInput}
                value={desiredTime}
                onChangeText={setDesiredTime}
                placeholder="e.g. Tomorrow, 01:00 PM"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Delivery Neighborhood</Text>
              <TextInput
                style={styles.textInput}
                value={location}
                onChangeText={setLocation}
                placeholder="e.g. Mikocheni B, Mtaa wa Chuo"
              />
            </View>

            <Button
              title={isSubmitted ? 'Update & Re-send Request' : 'Submit Meal Request'}
              onPress={handleSubmitRequest}
              variant="primary"
              size="lg"
              fullWidth={true}
              style={styles.submitBtn}
            />
          </View>
        )}

        {/* TAB 2: CHEF QUOTES RECEIVED */}
        {activeTab === 'QUOTES' && (
          <View style={styles.quotesSection}>
            <Text style={styles.quotesEyebrow}>
              {quotes.length} Verified Kitchens Responded:
            </Text>

            {quotes.map((q) => (
              <View key={q.id} style={styles.quoteCard}>
                <View style={styles.quoteCardHeader}>
                  <View>
                    <Text style={styles.quoteRestaurantName}>{q.restaurantName}</Text>
                    <View style={styles.quoteRatingRow}>
                      <Text style={styles.quoteStar}>★ {q.rating}</Text>
                      <Text style={styles.quoteReviews}>({q.reviews} verified reviews)</Text>
                    </View>
                  </View>
                  <PriceText amountTzs={q.priceTzs} size="md" color={Colors.primaryDark} />
                </View>

                <Text style={styles.quoteMessage}>"{q.message}"</Text>

                <View style={styles.inclusionsBox}>
                  <Text style={styles.inclusionsLabel}>Includes:</Text>
                  <Text style={styles.inclusionsText}>{q.inclusions}</Text>
                </View>

                <View style={styles.quoteFooter}>
                  <Text style={styles.prepTimeText}>⏱ Ready in ~{q.prepTimeMinutes} mins</Text>
                  <Button
                    title="Accept Quote & Order"
                    onPress={() => handleAcceptQuote(q)}
                    variant="primary"
                    size="sm"
                  />
                </View>
              </View>
            ))}

            {quotes.length === 0 && (
              <EmptyState
                title="No quotes received yet"
                message="Submit your meal request and nearby kitchens will offer quotes within a few minutes."
                icon="flame-outline"
                actionTitle="Submit Request"
                onAction={() => setActiveTab('REQUEST')}
              />
            )}
          </View>
        )}
      </ScrollView>

      {/* Floating Cart Button */}
      <FloatingCartButton />

      {/* Slide-in Cart Drawer */}
      <CartDrawer
        visible={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onProceedToCheckout={() => setIsOrderReviewOpen(true)}
      />

      {/* Order Review & Placement Modal */}
      <OrderReviewModal
        visible={isOrderReviewOpen}
        onClose={() => setIsOrderReviewOpen(false)}
        onOrderConfirmed={() => {}}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: Spacing.md,
    paddingBottom: 100,
  },
  largeScreenContainer: {
    maxWidth: 800,
    width: '100%',
    alignSelf: 'center',
  },
  header: {
    marginBottom: Spacing.md,
  },
  eyebrow: {
    fontSize: 11,
    fontWeight: '800',
    color: Colors.primary,
    letterSpacing: 0.5,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: Colors.textPrimary,
    marginTop: 2,
  },
  subtitle: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 4,
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radii.lg,
    padding: 4,
    marginBottom: Spacing.md,
  },
  tabBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: Radii.md,
  },
  tabBtnActive: {
    backgroundColor: Colors.primary,
  },
  tabText: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  tabTextActive: {
    color: Colors.white,
    fontWeight: '700',
  },
  formCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Shadows.sm,
  },
  inputGroup: {
    marginBottom: Spacing.sm,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  textInput: {
    backgroundColor: Colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radii.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 10,
    fontSize: 14,
    color: Colors.textPrimary,
  },
  textArea: {
    minHeight: 70,
    textAlignVertical: 'top',
  },
  rowTwoCols: {
    flexDirection: 'row',
  },
  submitBtn: {
    marginTop: Spacing.sm,
  },
  quotesSection: {
    gap: Spacing.md,
  },
  quotesEyebrow: {
    fontSize: 13,
    fontWeight: '700',
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  quoteCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Shadows.sm,
  },
  quoteCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.xs,
  },
  quoteRestaurantName: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  quoteRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  quoteStar: {
    fontSize: 12,
    fontWeight: '700',
    color: '#D97706',
    marginRight: 4,
  },
  quoteReviews: {
    fontSize: 11,
    color: Colors.textMuted,
  },
  quoteMessage: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontStyle: 'italic',
    marginVertical: Spacing.xs,
  },
  inclusionsBox: {
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radii.sm,
    padding: Spacing.xs,
    marginVertical: Spacing.xs,
  },
  inclusionsLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: Colors.textMuted,
  },
  inclusionsText: {
    fontSize: 12,
    color: Colors.textPrimary,
    marginTop: 1,
  },
  quoteFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.sm,
    paddingTop: Spacing.xs,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  prepTimeText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.textMuted,
  },
});
