import {
  UserEntity,
  UserRole,
  CustomerProfileEntity,
  RestaurantEntity,
  RestaurantMembershipEntity,
  RefreshSessionEntity,
  RegisterCustomerDTO,
  RegisterRestaurantDTO,
  LoginDTO,
  AuthSessionResponse,
  isMembershipActive,
  getUserRoles,
} from '../types';
import { CryptoEngine } from './crypto';
import { authorizeAccountRole } from './guards';
import { MloHubDB } from '../index';
import { getSmsProvider } from '../../services/sms/SmsProvider';

// Rate Limiter tracking (in-memory per client)
const loginAttempts: { [key: string]: { count: number; lastAttempt: number } } = {};
const RATE_LIMIT_MAX = 6;
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute

function checkRateLimit(key: string): boolean {
  const now = Date.now();
  const record = loginAttempts[key];
  if (!record) {
    loginAttempts[key] = { count: 1, lastAttempt: now };
    return true;
  }
  if (now - record.lastAttempt > RATE_LIMIT_WINDOW_MS) {
    loginAttempts[key] = { count: 1, lastAttempt: now };
    return true;
  }
  if (record.count >= RATE_LIMIT_MAX) {
    return false;
  }
  record.count++;
  record.lastAttempt = now;
  return true;
}

export const AuthService = {
  /**
   * Send Customer OTP Verification Code via SMS (Beem Africa / NextSMS / Sandbox)
   */
  async sendCustomerOtp(phone: string, purpose: string = 'Uthibitisho'): Promise<{
    success: boolean;
    carrierName: string;
    message: string;
    error?: string;
  }> {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (!cleanPhone || cleanPhone.length < 9) {
      return {
        success: false,
        carrierName: 'Unknown',
        message: 'Invalid phone number format. Please provide a valid number.',
      };
    }

    // Generate random 6-digit cryptographic OTP
    const rawOtp = `${Math.floor(100000 + Math.random() * 900000)}`;
    const otpHash = CryptoEngine.hashOtp(rawOtp, cleanPhone);
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 min expiry

    // Save Challenge in Database
    await MloHubDB.init();
    await MloHubDB.otpChallenges.create({
      phone: cleanPhone,
      otpHash,
      purpose: 'CUSTOMER_VERIFICATION',
      attemptsCount: 0,
      maxAttempts: 3,
      isVerified: false,
      expiresAt,
    });

    // Detect Tanzanian carrier
    let carrier = 'Vodacom M-Pesa';
    if (cleanPhone.includes('78') || cleanPhone.includes('68') || cleanPhone.includes('69')) carrier = 'Airtel Money';
    else if (cleanPhone.includes('71') || cleanPhone.includes('65') || cleanPhone.includes('67')) carrier = 'Mixx by Yas (Tigo)';
    else if (cleanPhone.includes('62') || cleanPhone.includes('61')) carrier = 'HaloPesa (Halotel)';

    // Dispatch via configured SMS Gateway
    const smsProvider = getSmsProvider();
    const smsResult = await smsProvider.sendOtp(cleanPhone, rawOtp, purpose);

    // Audit Log entry
    await MloHubDB.auditLogs.create({
      adminUserId: 'system',
      adminName: 'MloHub Customer SMS Gateway',
      action: 'SEND_CUSTOMER_OTP',
      targetType: 'PHONE',
      targetId: cleanPhone,
      details: { carrier, provider: smsProvider.name, success: smsResult.success },
    });

    return {
      success: smsResult.success,
      carrierName: carrier,
      message: smsResult.success
        ? `Nambari ya siri ya uthibitisho imetumwa kwa SMS (${carrier}).`
        : (smsResult.error || 'Failed to dispatch SMS OTP.'),
      error: smsResult.error,
    };
  },

  /**
   * Verify Customer OTP Code
   */
  async verifyCustomerOtp(
    phone: string,
    enteredOtp: string
  ): Promise<{ success: boolean; message: string }> {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (!enteredOtp || enteredOtp.trim().length === 0) {
      return { success: false, message: 'Please enter the 6-digit verification code.' };
    }

    await MloHubDB.init();
    const challenge = await MloHubDB.otpChallenges.getActiveByPhone(cleanPhone);

    if (!challenge) {
      return {
        success: false,
        message: 'No active OTP request found for this phone number. Please request a new code.',
      };
    }

    if (new Date(challenge.expiresAt).getTime() < Date.now()) {
      return {
        success: false,
        message: 'Verification code has expired. Please request a new code.',
      };
    }

    if (challenge.attemptsCount >= challenge.maxAttempts) {
      return {
        success: false,
        message: 'Maximum verification attempts exceeded. Code has been invalidated for security.',
      };
    }

    await MloHubDB.otpChallenges.incrementAttempts(challenge.id);

    const isValid = CryptoEngine.verifyOtpHash(enteredOtp.trim(), cleanPhone, challenge.otpHash);
    if (!isValid) {
      const remaining = Math.max(0, challenge.maxAttempts - challenge.attemptsCount);
      return {
        success: false,
        message: `Incorrect verification code. ${remaining} attempt(s) remaining.`,
      };
    }

    await MloHubDB.otpChallenges.markVerified(challenge.id);

    // Update existing user if found
    const db = MloHubDB.getSnapshot();
    const existingUser = db.users.find((u) => u.phone.replace(/[^0-9]/g, '') === cleanPhone);
    if (existingUser) {
      existingUser.isPhoneVerified = true;
      existingUser.updatedAt = new Date().toISOString();
      await MloHubDB.save();
    }

    return {
      success: true,
      message: 'Phone number verified successfully.',
    };
  },
  /**
   * Register a new Customer Account
   */
  async registerCustomer(dto: RegisterCustomerDTO): Promise<AuthSessionResponse> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    // Validation
    const cleanEmail = dto.email.trim().toLowerCase();
    const cleanPhone = dto.phone.trim();
    const cleanName = dto.fullName.trim();

    if (!cleanName || cleanName.length < 2) {
      throw new Error('Full name is required (minimum 2 characters).');
    }
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      throw new Error('Please provide a valid email address.');
    }
    if (!cleanPhone || cleanPhone.length < 9) {
      throw new Error('Please provide a valid phone number (e.g. +255 754 123 456).');
    }
    if (!dto.password || dto.password.length < 6) {
      throw new Error('Password must be at least 6 characters long.');
    }
    if (!dto.agreeTerms) {
      throw new Error('You must agree to the Terms of Service and Privacy Policy.');
    }

    // Check duplicate email or phone
    const existingEmail = db.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existingEmail) {
      throw new Error('An account with this email address already exists.');
    }
    const existingPhone = db.users.find((u) => u.phone === cleanPhone);
    if (existingPhone) {
      throw new Error('An account with this phone number already exists.');
    }

    // Create User
    const userId = `usr-${Date.now()}`;
    const passwordHash = CryptoEngine.hashPassword(dto.password);
    const now = new Date().toISOString();

    const newUser: UserEntity = {
      id: userId,
      fullName: cleanName,
      email: cleanEmail,
      phone: cleanPhone,
      passwordHash,
      role: UserRole.CUSTOMER,
      activeRole: UserRole.CUSTOMER,
      location: dto.location || 'Dar es Salaam',
      language: 'en',
      avatarEmoji: '👤',
      securityPin: '1234',
      isEmailVerified: false,
      isPhoneVerified: false,
      memberSince: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      createdAt: now,
      updatedAt: now,
    };

    // Create Customer Profile
    const profileId = `cp-${Date.now()}`;
    const newProfile: CustomerProfileEntity = {
      id: profileId,
      userId,
      deliveryAddress: dto.location || 'Dar es Salaam',
      neighborhood: dto.location || 'Mikocheni',
      dietaryPreferences: dto.dietaryPreferences || [],
      favoriteCuisineTypes: ['Swahili', 'Healthy'],
      createdAt: now,
      updatedAt: now,
    };

    // Issue Distinct Token
    const jti = `sess_${CryptoEngine.generateSalt(24)}`;
    const token = CryptoEngine.signToken({
      userId,
      role: UserRole.CUSTOMER,
      email: cleanEmail,
      sessionId: jti,
      jti,
    });

    // Create Session
    const newSession: RefreshSessionEntity = {
      id: jti,
      sessionId: jti,
      userId,
      token,
      deviceInfo: 'Expo Mobile App',
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: now,
    };

    // Save to Database
    db.users.unshift(newUser);
    db.customerProfiles = db.customerProfiles || [];
    db.customerProfiles.unshift(newProfile);
    db.sessions = db.sessions || [];
    db.sessions.unshift(newSession);
    db.activeUserId = userId;

    await MloHubDB.save();

    return {
      user: newUser,
      customerProfile: newProfile,
      memberships: [],
      token,
    };
  },

  /**
   * Register a new Restaurant & Owner Account (Multi-step)
   */
  async registerRestaurant(dto: RegisterRestaurantDTO): Promise<AuthSessionResponse> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    // 1. Owner Validation
    const cleanOwnerEmail = dto.ownerEmail.trim().toLowerCase();
    const cleanOwnerPhone = dto.ownerPhone.trim();
    const cleanOwnerName = dto.ownerFullName.trim();

    if (!cleanOwnerName) throw new Error('Owner full name is required.');
    if (!cleanOwnerEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanOwnerEmail)) {
      throw new Error('Please provide a valid owner email.');
    }
    if (!cleanOwnerPhone) throw new Error('Owner phone number is required.');
    if (!dto.password || dto.password.length < 6) {
      throw new Error('Password must be at least 6 characters long.');
    }

    // 2. Restaurant Validation
    const cleanRestName = dto.restaurantName.trim();
    if (!cleanRestName) throw new Error('Restaurant name is required.');
    if (!dto.cuisine.trim()) throw new Error('Cuisine / Category is required.');
    if (!dto.address.trim()) throw new Error('Physical restaurant address is required.');
    if (!dto.agreeTerms) throw new Error('You must agree to the Merchant Terms of Service.');

    // Duplicate check
    if (db.users.some((u) => u.email.toLowerCase() === cleanOwnerEmail)) {
      throw new Error('An account with this email already exists.');
    }

    const now = new Date().toISOString();
    const userId = `usr-chef-${Date.now()}`;
    const restaurantId = `rest-${cleanRestName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString().slice(-4)}`;

    // Create Owner User
    const newOwner: UserEntity = {
      id: userId,
      fullName: cleanOwnerName,
      email: cleanOwnerEmail,
      phone: cleanOwnerPhone,
      passwordHash: CryptoEngine.hashPassword(dto.password),
      role: UserRole.RESTAURANT_OWNER,
      activeRole: UserRole.RESTAURANT_OWNER,
      activeRestaurantId: restaurantId,
      location: dto.address,
      language: 'en',
      avatarEmoji: '👑',
      securityPin: '1234',
      companyOrGroup: cleanRestName,
      memberSince: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      createdAt: now,
      updatedAt: now,
    };

    // Create Restaurant Entity (with PENDING_VERIFICATION)
    const newRestaurant: RestaurantEntity = {
      id: restaurantId,
      ownerId: userId,
      ownerName: cleanOwnerName,
      ownerPhone: cleanOwnerPhone,
      sellerTier: 'BASIC_SELLER',
      name: cleanRestName,
      slug: restaurantId,
      cuisine: dto.cuisine,
      description: dto.description || `${cleanRestName} specializing in authentic fresh dishes.`,
      rating: 5.0,
      reviews: 0,
      price: 'TZS 10,000 - 30,000',
      minPrice: 10000,
      maxPrice: 30000,
      budgetTier: 'mid',
      address: dto.address,
      neighborhood: dto.neighborhood || 'Mikocheni',
      regionCity: dto.regionCity || 'Dar es Salaam',
      distance: '1.2 km',
      distanceKm: 1.2,
      time: '25-35m',
      isOpen: true,
      isVerified: false,
      verificationStatus: 'PENDING_VERIFICATION',
      businessRegNumber: dto.businessRegNumber || undefined,
      verificationDocUrl: dto.verificationDocUrl || undefined,
      openingHours: dto.openingHours || '08:00 AM',
      closingHours: dto.closingHours || '10:00 PM',
      logoUrl: dto.logoUrl,
      coverImageUrl: dto.coverImageUrl,
      specialty: `${dto.cuisine} Specialist`,
      specialistBadge: `👑 ${dto.cuisine} Specialist`,
      specialistBadgeSw: `👑 Mtaalamu wa ${dto.cuisine}`,
      specialistCategory: dto.cuisine.toLowerCase(),
      emoji: '🍽️',
      bgGradient: ['#113a26', '#1d6637'],
      tags: [dto.cuisine, 'Fresh Cook', 'Advance Batch'],
      lat: dto.lat || -6.7780,
      lng: dto.lng || 39.2660,
      supportsOrderAhead: true,
      maxGroupCapacity: 50,
      menu: [],
      createdAt: now,
      updatedAt: now,
    };

    // Create Restaurant Membership
    const membershipId = `rm-${Date.now()}`;
    const newMembership: RestaurantMembershipEntity = {
      id: membershipId,
      userId,
      restaurantId,
      role: 'OWNER',
      permissions: ['MANAGE_MENU', 'MANAGE_ORDERS', 'MANAGE_RESERVATIONS', 'VIEW_FINANCES', 'MANAGE_STAFF'],
      isPrimaryOwner: true,
      createdAt: now,
    };

    // Issue Distinct Token
    const jti = `sess_${CryptoEngine.generateSalt(24)}`;
    const token = CryptoEngine.signToken({
      userId,
      role: UserRole.RESTAURANT_OWNER,
      email: cleanOwnerEmail,
      restaurantId,
      sessionId: jti,
      jti,
    });

    // Create Session
    const newSession: RefreshSessionEntity = {
      id: jti,
      sessionId: jti,
      userId,
      token,
      deviceInfo: 'Expo Mobile App (Merchant Portal)',
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: now,
    };

    // Save to Database
    db.users.unshift(newOwner);
    db.restaurants.unshift(newRestaurant);
    db.restaurantMemberships = db.restaurantMemberships || [];
    db.restaurantMemberships.unshift(newMembership);
    db.sessions = db.sessions || [];
    db.sessions.unshift(newSession);
    db.activeUserId = userId;

    await MloHubDB.save();

    return {
      user: newOwner,
      memberships: [newMembership],
      activeRestaurant: newRestaurant,
      token,
    };
  },

  /**
   * Unified Shared Login for all Account Types
   */
  async login(dto: LoginDTO): Promise<AuthSessionResponse> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    const cleanInput = dto.emailOrPhone.trim().toLowerCase();
    if (!cleanInput) {
      throw new Error('Please enter your email or phone number.');
    }
    if (!dto.password) {
      throw new Error('Please enter your password.');
    }

    // Rate Limiter
    if (!checkRateLimit(cleanInput)) {
      throw new Error('Too many login attempts. Please wait 1 minute before trying again.');
    }

    // Find User by email or phone (supports both 07xx and +255xx formats)
    const digitsOnly = cleanInput.replace(/[^0-9]/g, '');
    const normClean = digitsOnly.startsWith('0') ? '255' + digitsOnly.slice(1) : digitsOnly;

    const user = db.users.find((u) => {
      if (u.email.toLowerCase() === cleanInput) return true;
      const uDigits = (u.phone || '').replace(/[^0-9]/g, '');
      const normU = uDigits.startsWith('0') ? '255' + uDigits.slice(1) : uDigits;
      return (
        (normClean.length >= 9 && normClean === normU) ||
        (u.phone && u.phone.replace(/[\s-]/g, '') === cleanInput.replace(/[\s-]/g, ''))
      );
    });

    if (!user) {
      // Avoid revealing account existence
      throw new Error('Invalid email/phone or password. Please check your credentials.');
    }

    // Reject explicitly suspended or inactive accounts
    if (user.status === 'SUSPENDED' || user.status === 'INACTIVE') {
      throw new Error('This account has been suspended or deactivated. Please contact support.');
    }

    // Verify Password (no PIN bypass, no master passwords, do not trim password)
    const isValid = CryptoEngine.verifyPassword(
      dto.password,
      user.passwordHash
    );

    if (!isValid) {
      throw new Error(
        'Invalid email/phone or password. Please check your credentials.'
      );
    }

    // Transparently upgrade legacy mlohub_v1 hash to modern mlohub_v2
    if (CryptoEngine.shouldUpgradeHash(user.passwordHash)) {
      user.passwordHash = CryptoEngine.hashPassword(dto.password);
    }

    // Resolve Customer Profile & Memberships strictly via active status
    const customerProfile = db.customerProfiles?.find((cp) => cp.userId === user.id);
    const userMemberships = db.restaurantMemberships?.filter((rm) => rm.userId === user.id) || [];
    const activeMemberships = userMemberships.filter((m) => isMembershipActive(m));

    const userRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];
    const isAdmin = userRoles.includes(UserRole.ADMIN) || userRoles.includes(UserRole.SUPER_ADMIN);

    let activeRestId: string | undefined = undefined;
    if (user.activeRestaurantId) {
      const hasMem = activeMemberships.some((m) => m.restaurantId === user.activeRestaurantId);
      const restExists = db.restaurants.some((r) => r.id === user.activeRestaurantId);
      if (restExists && (hasMem || isAdmin)) {
        activeRestId = user.activeRestaurantId;
      }
    }
    if (!activeRestId && activeMemberships.length > 0) {
      const candidateRest = db.restaurants.find((r) => r.id === activeMemberships[0].restaurantId);
      if (candidateRest) {
        activeRestId = candidateRest.id;
      }
    }

    const activeRestaurant = activeRestId ? db.restaurants.find((r) => r.id === activeRestId) : undefined;

    // Issue Distinct Token with verified restaurantId (or undefined for unassigned accounts)
    const jti = `sess_${CryptoEngine.generateSalt(24)}`;
    const token = CryptoEngine.signToken({
      userId: user.id,
      role: user.activeRole || user.role,
      email: user.email,
      restaurantId: activeRestId,
      sessionId: jti,
      jti,
    });

    // Store Session
    const newSession: RefreshSessionEntity = {
      id: jti,
      sessionId: jti,
      userId: user.id,
      token,
      deviceInfo: 'Expo Mobile App',
      expiresAt: new Date(Date.now() + (dto.rememberMe ? 60 : 30) * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
    };

    db.sessions = db.sessions || [];
    db.sessions.unshift(newSession);
    db.activeUserId = user.id;

    await MloHubDB.save();

    return {
      user,
      customerProfile,
      memberships: activeMemberships,
      activeRestaurant,
      token,
    };
  },

  /**
   * Get list of authorized workspaces for a user based on verified roles and memberships
   */
  async getAuthorizedWorkspaces(userId: string): Promise<{
    type: 'CUSTOMER' | 'RESTAURANT_OWNER' | 'MLOHUB_ADMIN';
    name: string;
    subtitle: string;
    icon: string;
    role: UserRole;
    restaurantId?: string;
  }[]> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    const user = db.users.find((u) => u.id === userId);
    if (!user) return [];

    const userRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];
    const workspaces: {
      type: 'CUSTOMER' | 'RESTAURANT_OWNER' | 'MLOHUB_ADMIN';
      name: string;
      subtitle: string;
      icon: string;
      role: UserRole;
      restaurantId?: string;
    }[] = [];

    // 1. Personal Account — Customer (always available to valid users)
    workspaces.push({
      type: 'CUSTOMER',
      name: 'Personal Account',
      subtitle: 'Customer',
      icon: 'person-circle',
      role: UserRole.CUSTOMER,
    });

    // 2. Restaurant Owner Workspaces (only for verified active restaurant memberships)
    const memberships = db.restaurantMemberships?.filter(
      (rm) => rm.userId === userId && isMembershipActive(rm)
    ) || [];

    for (const mem of memberships) {
      const rest = db.restaurants.find((r) => r.id === mem.restaurantId);
      if (rest) {
        workspaces.push({
          type: 'RESTAURANT_OWNER',
          name: rest.name,
          subtitle: 'Restaurant Owner',
          icon: 'restaurant',
          role: UserRole.RESTAURANT_OWNER,
          restaurantId: rest.id,
        });
      }
    }

    // 3. MloHub Administration (ONLY if user has ADMIN or SUPER_ADMIN role)
    const isAdmin = userRoles.includes(UserRole.ADMIN) || userRoles.includes(UserRole.SUPER_ADMIN);
    if (isAdmin) {
      const isSuper = userRoles.includes(UserRole.SUPER_ADMIN);
      workspaces.push({
        type: 'MLOHUB_ADMIN',
        name: 'MloHub Administration',
        subtitle: isSuper ? 'Super Admin' : 'Admin',
        icon: 'shield-checkmark',
        role: isSuper ? UserRole.SUPER_ADMIN : UserRole.ADMIN,
      });
    }

    return workspaces;
  },

  /**
   * Switch Context between authorized workspaces with strict server-side validation
   */
  /**
   * Switch Context between authorized workspaces with strict server-side validation.
   * Exclusively accepts a validated, active session token (user-ID shortcut is deleted).
   */
  async switchWorkspace(
    currentToken: string,
    targetWorkspace: 'CUSTOMER' | 'RESTAURANT_OWNER' | 'MLOHUB_ADMIN',
    restaurantId?: string
  ): Promise<AuthSessionResponse> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    if (!currentToken || typeof currentToken !== 'string' || !currentToken.includes('.')) {
      throw new Error('401 Unauthorized: Valid session token is required to switch workspace.');
    }

    const verified = await this.verifySession(currentToken);
    if (!verified) {
      throw new Error('401 Unauthorized: Valid active session is required to switch workspace.');
    }

    const user = verified.user;
    const currentSession = db.sessions?.find((s) => s.token === currentToken);
    if (!currentSession) {
      throw new Error('401 Unauthorized: Stored session matching current token not found.');
    }

    if (user.status === 'SUSPENDED' || user.status === 'INACTIVE') {
      throw new Error('403 Forbidden: Account is suspended or inactive.');
    }

    const userRoles = getUserRoles(user);
    const isAdmin = userRoles.includes(UserRole.ADMIN) || userRoles.includes(UserRole.SUPER_ADMIN);
    const activeMemberships = (db.restaurantMemberships || []).filter(
      (rm) => rm.userId === user.id && isMembershipActive(rm)
    );

    let targetRole = UserRole.CUSTOMER;
    let resolvedRestId: string | undefined = undefined;

    if (targetWorkspace === 'CUSTOMER') {
      targetRole = UserRole.CUSTOMER;
      resolvedRestId = undefined;
    } else if (targetWorkspace === 'RESTAURANT_OWNER') {
      if (!restaurantId) {
        if (activeMemberships.length === 0 && !isAdmin) {
          throw new Error('403 Forbidden: You do not have an active membership for any restaurant.');
        }
        resolvedRestId = activeMemberships.length > 0 ? activeMemberships[0].restaurantId : undefined;
      } else {
        // Validate restaurant exists in database first
        const rest = db.restaurants.find((r) => r.id === restaurantId);
        if (!rest) {
          throw new Error(`404 Not Found: Restaurant '${restaurantId}' does not exist.`);
        }
        const hasMembership = activeMemberships.some((m) => m.restaurantId === restaurantId);
        if (!hasMembership && !isAdmin) {
          throw new Error('403 Forbidden: You do not have an active membership for this restaurant.');
        }
        resolvedRestId = restaurantId;
      }

      if (!resolvedRestId && !isAdmin) {
        throw new Error('403 Forbidden: An authorized restaurant ID is required.');
      }

      targetRole = isAdmin
        ? (userRoles.includes(UserRole.SUPER_ADMIN) ? UserRole.SUPER_ADMIN : UserRole.ADMIN)
        : UserRole.RESTAURANT_OWNER;
    } else if (targetWorkspace === 'MLOHUB_ADMIN') {
      if (!isAdmin) {
        throw new Error('403 Forbidden: You do not have permission to access MloHub Administration.');
      }
      targetRole = userRoles.includes(UserRole.SUPER_ADMIN) ? UserRole.SUPER_ADMIN : UserRole.ADMIN;
      resolvedRestId = undefined;
    }

    // Shared role-authorization entitlement check BEFORE any state mutations
    const entitlement = authorizeAccountRole(user, targetRole, resolvedRestId);
    if (!entitlement.isAuthorized) {
      throw new Error(entitlement.error || '403 Forbidden: Insufficient role permissions.');
    }

    // Invalidate the current session token being replaced while keeping unrelated device sessions intact
    db.sessions = (db.sessions || []).filter((s) => s.token !== currentSession.token);

    // Mutate user state only after successful validation
    user.activeRole = targetRole;
    user.activeWorkspace = targetWorkspace;
    user.activeRestaurantId = resolvedRestId;
    user.updatedAt = new Date().toISOString();

    const jti = `sess_${CryptoEngine.generateSalt(24)}`;
    const token = CryptoEngine.signToken({
      userId: user.id,
      role: targetRole,
      email: user.email,
      restaurantId: resolvedRestId,
      sessionId: jti,
      jti,
    });

    const newSession: RefreshSessionEntity = {
      id: jti,
      sessionId: jti,
      userId: user.id,
      token,
      deviceInfo: currentSession.deviceInfo || 'Expo Mobile App',
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
    };
    db.sessions = db.sessions || [];
    db.sessions.unshift(newSession);
    db.activeUserId = user.id;

    await MloHubDB.save();

    const customerProfile = db.customerProfiles?.find((cp) => cp.userId === user.id);
    const activeRestaurant = resolvedRestId ? db.restaurants.find((r) => r.id === resolvedRestId) : undefined;

    return {
      user,
      customerProfile,
      memberships: activeMemberships,
      activeRestaurant,
      token,
    };
  },

  /**
   * Switch Context between Customer and Restaurant Owner without re-login.
   * Token-only contract.
   */
  async switchAccountContext(
    currentToken: string,
    targetRole: UserRole,
    restaurantId?: string
  ): Promise<AuthSessionResponse> {
    const ws: 'CUSTOMER' | 'RESTAURANT_OWNER' | 'MLOHUB_ADMIN' =
      targetRole === UserRole.ADMIN || targetRole === UserRole.SUPER_ADMIN
        ? 'MLOHUB_ADMIN'
        : targetRole === UserRole.RESTAURANT_OWNER || targetRole === UserRole.RESTAURANT_STAFF
        ? 'RESTAURANT_OWNER'
        : 'CUSTOMER';
    return this.switchWorkspace(currentToken, ws, restaurantId);
  },

  /**
   * Logout current session
   */
  async logout(token: string): Promise<boolean> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    if (db.sessions) {
      db.sessions = db.sessions.filter((s) => s.token !== token);
    }
    db.activeUserId = undefined;
    await MloHubDB.save();
    return true;
  },

  /**
   * Bootstrap session from active session token
   */
  async bootstrapSession(): Promise<AuthSessionResponse | null> {
    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();
    const activeUserId = db.activeUserId;
    if (!activeUserId) return null;

    const session = db.sessions?.find(
      (s) => s.userId === activeUserId && new Date(s.expiresAt).getTime() > Date.now()
    );
    if (!session || !session.token) {
      db.activeUserId = undefined;
      await MloHubDB.save();
      return null;
    }

    const verified = await this.verifySession(session.token);
    if (!verified) {
      db.activeUserId = undefined;
      db.sessions = (db.sessions || []).filter((s) => s.token !== session.token);
      await MloHubDB.save();
      return null;
    }

    return verified;
  },

  /**
   * Verify token and restore session with strict security validations
   */
  async verifySession(token: string): Promise<AuthSessionResponse | null> {
    if (!token || typeof token !== 'string') return null;
    const payload = CryptoEngine.verifyToken(token);
    if (!payload || !payload.userId) return null;

    // Validate token expiry (finite and not expired)
    if (typeof payload.exp !== 'number' || !Number.isFinite(payload.exp) || payload.exp <= Date.now()) {
      return null;
    }

    await MloHubDB.init();
    const db = MloHubDB.getSnapshot();

    // A matching stored session record must exist
    const sessionRecord = db.sessions?.find((s) => s.token === token);
    if (!sessionRecord) return null;

    // Stored session user ID must match the token user ID
    if (sessionRecord.userId !== payload.userId) return null;

    // Stored-session expiry must be valid and unexpired
    const sessionExpiryMs = new Date(sessionRecord.expiresAt).getTime();
    if (isNaN(sessionExpiryMs) || !Number.isFinite(sessionExpiryMs) || sessionExpiryMs <= Date.now()) {
      return null;
    }

    // User must exist and not be suspended/inactive
    const user = db.users.find((u) => u.id === payload.userId);
    if (!user || user.status === 'SUSPENDED' || user.status === 'INACTIVE') {
      return null;
    }

    // Confirm account still holds entitlement to the role/workspace claimed by the token
    const claimedRole = (payload.role as UserRole) || UserRole.CUSTOMER;
    const entitlement = authorizeAccountRole(user, claimedRole, payload.restaurantId);
    if (!entitlement.isAuthorized) {
      return null;
    }

    // Resolve active memberships
    const userMemberships = db.restaurantMemberships?.filter((rm) => rm.userId === user.id) || [];
    const activeMemberships = userMemberships.filter((m) => isMembershipActive(m));

    // Restaurant context must match a valid membership (role alone never bypasses)
    const userRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];
    const isAdmin = userRoles.includes(UserRole.ADMIN) || userRoles.includes(UserRole.SUPER_ADMIN);

    let activeRestaurant: RestaurantEntity | undefined = undefined;
    // CRITICAL: Do NOT reconstruct an old token's restaurant context using a later user.activeRestaurantId value!
    const targetRestId = payload.restaurantId;

    if (targetRestId) {
      const rest = db.restaurants.find((r) => r.id === targetRestId);
      if (!rest) {
        return null;
      }
      const mem = activeMemberships.find((m) => m.restaurantId === targetRestId);
      if (!mem && !isAdmin) {
        return null;
      }
      activeRestaurant = rest;
    }

    const customerProfile = db.customerProfiles?.find((cp) => cp.userId === user.id);

    return {
      user,
      customerProfile,
      memberships: activeMemberships,
      activeRestaurant,
      token,
    };
  },
};
