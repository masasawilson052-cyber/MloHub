import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../theme/colors';
import { Spacing } from '../../theme/spacing';
import { Radii } from '../../theme/radius';
import { Shadows } from '../../theme/shadows';
import { Typography } from '../../theme/typography';
import { Reservation, ReservationStatus } from '../../types/domain';
import { Badge } from '../ui/Badge';
import { EmptyState } from '../ui/EmptyState';
import { Button } from '../ui/Button';

export interface ReservationManagerProps {
  reservations: Reservation[];
  onUpdateStatus: (reservationId: string, nextStatus: ReservationStatus) => Promise<void>;
  maxTablesCapacity?: number;
  language?: 'en' | 'sw';
}

export const ReservationManager: React.FC<ReservationManagerProps> = ({
  reservations,
  onUpdateStatus,
  maxTablesCapacity = 15,
  language = 'en',
}) => {
  const [activeTab, setActiveTab] = useState<ReservationStatus | 'TODAY' | 'ALL'>('TODAY');

  const todayStr = new Date().toISOString().split('T')[0];

  const filteredReservations = reservations.filter((r) => {
    if (activeTab === 'ALL') return true;
    if (activeTab === 'TODAY') {
      return r.reservationDate?.startsWith(todayStr) && r.status !== 'CANCELLED';
    }
    return r.status === activeTab;
  });

  const todayConfirmedCount = reservations.filter(
    (r) => r.reservationDate?.startsWith(todayStr) && (r.status === 'CONFIRMED' || r.status === 'PENDING')
  ).length;

  const isNearCapacity = todayConfirmedCount >= maxTablesCapacity * 0.8;

  const getStatusBadge = (status: ReservationStatus) => {
    switch (status) {
      case 'PENDING':
        return <Badge label="Pending" variant="warning" size="sm" />;
      case 'CONFIRMED':
        return <Badge label="Confirmed" variant="success" size="sm" />;
      case 'SEATED':
        return <Badge label="Seated / Completed" variant="neutral" size="sm" />;
      case 'CANCELLED':
        return <Badge label="Cancelled" variant="error" size="sm" />;
      case 'NO_SHOW':
        return <Badge label="No-Show" variant="error" size="sm" />;
      default:
        return <Badge label={status} variant="neutral" size="sm" />;
    }
  };

  return (
    <View style={styles.container}>
      {/* Capacity Health Banner */}
      <View style={[styles.capacityBanner, isNearCapacity && styles.capacityBannerWarning]}>
        <View style={styles.capacityLeft}>
          <Ionicons
            name={isNearCapacity ? 'warning-outline' : 'cafe-outline'}
            size={20}
            color={isNearCapacity ? '#B45309' : Colors.primaryDark}
          />
          <View>
            <Text style={styles.capacityTitle}>
              {language === 'sw' ? 'Uwezo wa Meza za Leo' : "Today's Table Capacity"}
            </Text>
            <Text style={styles.capacitySub}>
              {todayConfirmedCount} / {maxTablesCapacity} tables booked for today
            </Text>
          </View>
        </View>

        {isNearCapacity && (
          <View style={styles.busyPill}>
            <Text style={styles.busyPillText}>Almost Full</Text>
          </View>
        )}
      </View>

      {/* Tabs Filter */}
      <View style={styles.filterRow}>
        {(['TODAY', 'PENDING', 'CONFIRMED', 'SEATED', 'ALL'] as const).map((tab) => {
          const isActive = activeTab === tab;
          let count = 0;
          if (tab === 'TODAY') count = reservations.filter((r) => r.reservationDate?.startsWith(todayStr) && r.status !== 'CANCELLED').length;
          else if (tab === 'ALL') count = reservations.length;
          else count = reservations.filter((r) => r.status === tab).length;

          return (
            <TouchableOpacity
              key={tab}
              style={[styles.filterChip, isActive && styles.filterChipActive]}
              onPress={() => setActiveTab(tab)}
              accessibilityRole="button"
            >
              <Text style={[styles.filterChipText, isActive && styles.filterChipTextActive]}>
                {tab === 'TODAY' ? "Today's Bookings" : tab === 'PENDING' ? 'Pending' : tab === 'CONFIRMED' ? 'Confirmed' : tab === 'SEATED' ? 'Seated' : 'All'}
              </Text>
              {count > 0 && (
                <View style={[styles.filterCountBadge, isActive && styles.filterCountBadgeActive]}>
                  <Text style={[styles.filterCountText, isActive && styles.filterCountTextActive]}>
                    {count}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Reservations List */}
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.listContainer}>
        {filteredReservations.length === 0 ? (
          <EmptyState
            title="No Reservations Found"
            message="Guest table bookings and dining requests will appear here."
            icon="calendar-outline"
          />
        ) : (
          filteredReservations.map((res) => (
            <View key={res.id} style={styles.reservationCard}>
              <View style={styles.cardHeader}>
                <View style={styles.customerBlock}>
                  <Text style={styles.customerName}>
                    {(res as any).customerName || 'Dine-in Guest'}
                  </Text>
                  {(res as any).customerPhone && (
                    <Text style={styles.customerPhone}>📞 {(res as any).customerPhone}</Text>
                  )}
                </View>
                <View style={styles.headerRight}>
                  {getStatusBadge(res.status)}
                </View>
              </View>

              {/* Booking Details Grid */}
              <View style={styles.detailsGrid}>
                <View style={styles.detailItem}>
                  <Ionicons name="calendar-outline" size={15} color={Colors.textMuted} />
                  <Text style={styles.detailText}>{res.reservationDate || 'Today'}</Text>
                </View>
                <View style={styles.detailItem}>
                  <Ionicons name="time-outline" size={15} color={Colors.textMuted} />
                  <Text style={styles.detailText}>{res.reservationTime || '19:30'}</Text>
                </View>
                <View style={styles.detailItem}>
                  <Ionicons name="people-outline" size={15} color={Colors.textMuted} />
                  <Text style={styles.detailText}>{res.partySize} Guests</Text>
                </View>
                <View style={styles.detailItem}>
                  <Ionicons name="card-outline" size={15} color={Colors.textMuted} />
                  <Text style={styles.detailText}>
                    {res.isDepositPaid ? 'Deposit Paid ✓' : 'Pay on Arrival'}
                  </Text>
                </View>
              </View>

              {(res.customerNote || (res as any).specialRequest) && (
                <View style={styles.notesBox}>
                  <Text style={styles.notesLabel}>Special Request:</Text>
                  <Text style={styles.notesText}>{res.customerNote || (res as any).specialRequest}</Text>
                </View>
              )}

              {/* Action Buttons */}
              <View style={styles.actionsRow}>
                {res.status === 'PENDING' && (
                  <>
                    <Button
                      title="Reject"
                      onPress={() => onUpdateStatus(res.id, 'CANCELLED')}
                      variant="outline"
                      size="sm"
                      style={{ borderColor: Colors.error }}
                    />
                    <Button
                      title="Confirm Table ✓"
                      onPress={() => onUpdateStatus(res.id, 'CONFIRMED')}
                      variant="primary"
                      size="sm"
                    />
                  </>
                )}

                {res.status === 'CONFIRMED' && (
                  <>
                    <Button
                      title="No-Show"
                      onPress={() => onUpdateStatus(res.id, 'NO_SHOW')}
                      variant="ghost"
                      size="sm"
                    />
                    <Button
                      title="Seat / Completed ✓"
                      onPress={() => onUpdateStatus(res.id, 'SEATED')}
                      variant="secondary"
                      size="sm"
                    />
                  </>
                )}
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: Spacing.md,
    maxWidth: 1000,
    width: '100%',
    alignSelf: 'center',
  },
  capacityBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    padding: Spacing.md,
    borderRadius: Radii.lg,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    marginBottom: Spacing.md,
    ...Shadows.sm,
  },
  capacityBannerWarning: {
    backgroundColor: '#FFFBEB',
    borderColor: '#FDE68A',
  },
  capacityLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  capacityTitle: {
    ...Typography.BodyMedium,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  capacitySub: {
    ...Typography.Caption,
    color: Colors.textSecondary,
    marginTop: 1,
  },
  busyPill: {
    backgroundColor: '#F59E0B',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radii.full,
  },
  busyPillText: {
    ...Typography.Caption,
    color: Colors.white,
    fontWeight: '800',
    fontSize: 10,
  },
  filterRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.xs,
    marginBottom: Spacing.md,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: Radii.full,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    gap: 6,
  },
  filterChipActive: {
    backgroundColor: Colors.primaryDark,
    borderColor: Colors.primaryDark,
  },
  filterChipText: {
    ...Typography.Caption,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  filterChipTextActive: {
    color: Colors.white,
  },
  filterCountBadge: {
    backgroundColor: Colors.surfaceSecondary,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: Radii.full,
  },
  filterCountBadgeActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
  },
  filterCountText: {
    ...Typography.Caption,
    fontSize: 10,
    fontWeight: '700',
    color: Colors.textSecondary,
  },
  filterCountTextActive: {
    color: Colors.white,
  },
  listContainer: {
    gap: Spacing.sm,
    paddingBottom: Spacing.xl,
  },
  reservationCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    padding: Spacing.md,
    ...Shadows.sm,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    paddingBottom: Spacing.xs,
    marginBottom: Spacing.sm,
  },
  customerBlock: {
    gap: 2,
  },
  customerName: {
    ...Typography.H3,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  customerPhone: {
    ...Typography.Caption,
    color: Colors.textMuted,
  },
  headerRight: {},
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    marginVertical: Spacing.xs,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  detailText: {
    ...Typography.BodyMedium,
    color: Colors.textPrimary,
    fontSize: 13,
  },
  notesBox: {
    backgroundColor: Colors.surfaceSecondary,
    padding: Spacing.xs,
    borderRadius: Radii.sm,
    marginTop: Spacing.xs,
  },
  notesLabel: {
    ...Typography.Caption,
    fontWeight: '700',
    color: Colors.textSecondary,
    fontSize: 10.5,
  },
  notesText: {
    ...Typography.Body,
    color: Colors.textPrimary,
    fontSize: 12.5,
    marginTop: 2,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    paddingTop: Spacing.sm,
  },
});
