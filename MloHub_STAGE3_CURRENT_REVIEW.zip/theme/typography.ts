import type { TextStyle } from 'react-native';
import { Colors } from './colors';

const baseFont =
  typeof navigator !== 'undefined' && /iPhone|iPad|iPod/.test(navigator.userAgent || '')
    ? 'System'
    : typeof navigator !== 'undefined' && /Android/.test(navigator.userAgent || '')
    ? 'Roboto'
    : 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

export const Typography: Record<string, TextStyle> = {
  Display: {
    fontFamily: baseFont,
    fontSize: 32,
    lineHeight: 38,
    fontWeight: '700',
    color: Colors.textPrimary,
    letterSpacing: -0.5,
  },
  H1: {
    fontFamily: baseFont,
    fontSize: 24,
    lineHeight: 30,
    fontWeight: '700',
    color: Colors.textPrimary,
    letterSpacing: -0.3,
  },
  H2: {
    fontFamily: baseFont,
    fontSize: 20,
    lineHeight: 26,
    fontWeight: '600',
    color: Colors.textPrimary,
    letterSpacing: -0.2,
  },
  H3: {
    fontFamily: baseFont,
    fontSize: 16,
    lineHeight: 22,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  Body: {
    fontFamily: baseFont,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '400',
    color: Colors.textSecondary,
  },
  BodyMedium: {
    fontFamily: baseFont,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '500',
    color: Colors.textPrimary,
  },
  BodySemiBold: {
    fontFamily: baseFont,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  Caption: {
    fontFamily: baseFont,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '400',
    color: Colors.textMuted,
  },
  CaptionMedium: {
    fontFamily: baseFont,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
    color: Colors.textSecondary,
  },
  Label: {
    fontFamily: baseFont,
    fontSize: 11,
    lineHeight: 14,
    fontWeight: '600',
    color: Colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  PriceLarge: {
    fontFamily: baseFont,
    fontSize: 20,
    lineHeight: 24,
    fontWeight: '700',
    color: Colors.primaryDark,
  },
  PriceMedium: {
    fontFamily: baseFont,
    fontSize: 16,
    lineHeight: 20,
    fontWeight: '700',
    color: Colors.primaryDark,
  },
  PriceSmall: {
    fontFamily: baseFont,
    fontSize: 13,
    lineHeight: 16,
    fontWeight: '700',
    color: Colors.primaryDark,
  },
};
