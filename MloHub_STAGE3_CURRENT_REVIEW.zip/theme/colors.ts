/**
 * MloHub Centralized Color Tokens - Design System V2
 * Preserves the recognized MloHub culinary brand identity:
 * Deep Green, Warm Beige, Dark Charcoal Green, and Savory Accent Orange.
 */

export const Colors = {
  // Brand Primaries
  primary: '#1D6637',
  primaryDark: '#143C26',
  primaryLight: '#2F8F4E',
  primaryMuted: '#EAF4E7',
  lime: '#DFF2B9',

  // Accent & Energetic
  accent: '#ED8936',
  accentDark: '#C05621',
  accentLight: '#FFF8EB',

  // Surfaces & Backgrounds
  background: '#FBFAF4',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  surfaceSecondary: '#F4F6F4',
  surfaceElevated: '#FFFFFF',

  // Text Hierarchy
  text: '#14281E',
  textPrimary: '#14281E',
  textSecondary: '#536259',
  muted: '#536259',
  textMuted: '#77847C',
  subtle: '#77847C',
  textInverse: '#FFFFFF',
  textOnPrimary: '#FFFFFF',

  // Borders & Dividers
  border: '#DCE4DD',
  borderLight: '#EDF0ED',
  borderFocus: '#1D6637',

  // Status & Semantic Badges
  success: '#2F8F4E',
  successLight: '#EAF4E7',
  warning: '#D97706',
  warningLight: '#FEF3C7',
  error: '#E53E3E',
  errorLight: '#FEE2E2',
  info: '#2563EB',
  infoLight: '#EFF6FF',

  // State Overlays
  disabled: '#A0AEC0',
  disabledSurface: '#E2E8F0',
  disabledText: '#718096',
  overlay: 'rgba(20, 40, 30, 0.45)',

  // Pure Constants
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
} as const;

export type ColorToken = keyof typeof Colors;
