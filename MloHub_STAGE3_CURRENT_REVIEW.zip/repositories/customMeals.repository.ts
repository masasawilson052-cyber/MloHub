import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { CustomMealRequest, RestaurantQuote } from '../types/domain';

export class CustomMealRepository {
  private static mapRowToRequest(row: any, quotes?: RestaurantQuote[]): CustomMealRequest {
    return {
      id: row.id,
      orderNumber: row.order_number,
      customerId: row.user_id,
      title: row.dish_name,
      dishName: row.dish_name,
      description: row.special_instructions,
      specialInstructions: row.special_instructions,
      budgetTzs: row.budget_tzs || 0,
      servings: row.servings_count || '1',
      servingsCount: row.servings_count || '1',
      diningOption: row.dining_option || 'Delivery',
      preferredTime: row.preferred_time,
      deliveryLocation: row.delivery_location,
      status: row.status || 'PENDING',
      statusMessageEn: row.status_message_en,
      statusMessageSw: row.status_message_sw,
      acceptedQuoteId: row.accepted_quote_id,
      quotes: quotes || (row.restaurant_quotes || []).map(this.mapRowToQuote),
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || new Date().toISOString(),
    };
  }

  private static mapRowToQuote(row: any): RestaurantQuote {
    return {
      id: row.id,
      requestId: row.request_id,
      restaurantId: row.restaurant_id,
      restaurantName: row.restaurants?.name,
      amountTzs: row.quoted_price_tzs || 0,
      quotedPriceTzs: row.quoted_price_tzs || 0,
      estimatedPrepMinutes: row.estimated_prep_minutes || 30,
      message: row.chef_notes,
      chefNotes: row.chef_notes,
      status: row.status || 'OFFERED',
      createdAt: row.created_at || new Date().toISOString(),
    };
  }

  public static async createRequest(request: Partial<CustomMealRequest>): Promise<CustomMealRequest> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const id = request.id || `req_${Date.now()}`;
    const orderNumber = request.orderNumber || `MLO-${Date.now().toString().slice(-4)}`;

    const row = {
      id,
      order_number: orderNumber,
      user_id: request.customerId,
      dish_name: request.dishName || request.title || 'Custom Meal',
      special_instructions: request.specialInstructions || request.description || '',
      budget_tzs: request.budgetTzs || 15000,
      servings_count: request.servingsCount || request.servings || '1 Person',
      dining_option: request.diningOption || 'Delivery',
      delivery_location: request.deliveryLocation || request.location,
      preferred_time: request.preferredTime || request.desiredDate,
      status: request.status || 'PENDING',
      status_message_en: request.statusMessageEn || 'Order submitted. Awaiting chef bids.',
      status_message_sw: request.statusMessageSw || 'Agizo limetumwa. Inasubiri ofa za wapishi.',
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('custom_meal_requests')
      .insert(row)
      .select()
      .single();

    if (error) {
      console.error('CustomMealRepository.createRequest error:', error.message);
      throw new Error(`Failed to create custom meal request: ${error.message}`);
    }

    return this.mapRowToRequest(data);
  }

  public static async listRequestsForCustomer(customerId: string): Promise<CustomMealRequest[]> {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('custom_meal_requests')
      .select('*, restaurant_quotes(*, restaurants(name))')
      .eq('user_id', customerId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error(`CustomMealRepository.listRequestsForCustomer error:`, error.message);
      throw new Error(`Failed to list customer requests: ${error.message}`);
    }

    return (data || []).map((r) =>
      this.mapRowToRequest(r, (r.restaurant_quotes || []).map(this.mapRowToQuote))
    );
  }

  public static async listOpenRequests(): Promise<CustomMealRequest[]> {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('custom_meal_requests')
      .select('*, restaurant_quotes(*, restaurants(name))')
      .eq('status', 'PENDING')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('CustomMealRepository.listOpenRequests error:', error.message);
      throw new Error(`Failed to list open custom meal requests: ${error.message}`);
    }

    return (data || []).map((r) =>
      this.mapRowToRequest(r, (r.restaurant_quotes || []).map(this.mapRowToQuote))
    );
  }

  public static async submitQuote(quote: Partial<RestaurantQuote>): Promise<RestaurantQuote> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const row = {
      id: quote.id || `quote_${Date.now()}`,
      request_id: quote.requestId,
      restaurant_id: quote.restaurantId,
      quoted_price_tzs: quote.quotedPriceTzs || quote.amountTzs || 15000,
      estimated_prep_minutes: quote.estimatedPrepMinutes || 35,
      chef_notes: quote.chefNotes || quote.message,
      status: 'OFFERED',
    };

    const { data, error } = await supabase
      .from('restaurant_quotes')
      .insert(row)
      .select('*, restaurants(name)')
      .single();

    if (error) {
      console.error('CustomMealRepository.submitQuote error:', error.message);
      throw new Error(`Failed to submit quote: ${error.message}`);
    }

    return this.mapRowToQuote(data);
  }

  public static async acceptQuote(requestId: string, quoteId: string): Promise<CustomMealRequest> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    // Update accepted quote status
    await supabase
      .from('restaurant_quotes')
      .update({ status: 'ACCEPTED' })
      .eq('id', quoteId);

    // Update custom meal request
    const { data, error } = await supabase
      .from('custom_meal_requests')
      .update({
        status: 'ACCEPTED',
        accepted_quote_id: quoteId,
        status_message_en: 'Quote accepted! The kitchen is preparing your custom dish.',
        status_message_sw: 'Ofa imekubaliwa! Jiko linaandaa chakula chako maalum.',
        updated_at: new Date().toISOString(),
      })
      .eq('id', requestId)
      .select('*, restaurant_quotes(*, restaurants(name))')
      .single();

    if (error) {
      console.error('CustomMealRepository.acceptQuote error:', error.message);
      throw new Error(`Failed to accept quote: ${error.message}`);
    }

    return this.mapRowToRequest(data);
  }

  public static async updateRequest(
    id: string,
    updates: Partial<CustomMealRequest>
  ): Promise<CustomMealRequest> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const rowUpdates: any = {
      updated_at: new Date().toISOString(),
    };

    if (updates.dishName !== undefined || updates.title !== undefined) {
      rowUpdates.dish_name = updates.dishName || updates.title;
    }
    if (updates.specialInstructions !== undefined || updates.description !== undefined) {
      rowUpdates.special_instructions = updates.specialInstructions || updates.description;
    }
    if (updates.budgetTzs !== undefined) {
      rowUpdates.budget_tzs = updates.budgetTzs;
    }
    if (updates.servingsCount !== undefined || updates.servings !== undefined) {
      rowUpdates.servings_count = updates.servingsCount || updates.servings;
    }
    if (updates.diningOption !== undefined) {
      rowUpdates.dining_option = updates.diningOption;
    }
    if (updates.deliveryLocation !== undefined) {
      rowUpdates.delivery_location = updates.deliveryLocation;
    }
    if (updates.preferredTime !== undefined) {
      rowUpdates.preferred_time = updates.preferredTime;
    }
    if (updates.status !== undefined) {
      rowUpdates.status = updates.status;
    }
    if (updates.statusMessageEn !== undefined) {
      rowUpdates.status_message_en = updates.statusMessageEn;
    }
    if (updates.statusMessageSw !== undefined) {
      rowUpdates.status_message_sw = updates.statusMessageSw;
    }

    const { data, error } = await supabase
      .from('custom_meal_requests')
      .update(rowUpdates)
      .eq('id', id)
      .select('*, restaurant_quotes(*, restaurants(name))')
      .single();

    if (error) {
      console.error(`CustomMealRepository.updateRequest(${id}) error:`, error.message);
      throw new Error(`Failed to update custom meal request: ${error.message}`);
    }

    return this.mapRowToRequest(data, (data.restaurant_quotes || []).map(this.mapRowToQuote));
  }

  public static async cancelRequest(id: string): Promise<boolean> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const { error } = await supabase
      .from('custom_meal_requests')
      .update({
        status: 'CANCELLED',
        status_message_en: 'Custom meal request cancelled.',
        status_message_sw: 'Agizo maalum limesitishwa.',
        updated_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (error) {
      console.error(`CustomMealRepository.cancelRequest(${id}) error:`, error.message);
      throw new Error(`Failed to cancel custom meal request: ${error.message}`);
    }

    return true;
  }

  public static async deleteRequest(id: string): Promise<boolean> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const { error } = await supabase
      .from('custom_meal_requests')
      .delete()
      .eq('id', id);

    if (error) {
      console.error(`CustomMealRepository.deleteRequest(${id}) error:`, error.message);
      throw new Error(`Failed to delete custom meal request: ${error.message}`);
    }

    return true;
  }
}
