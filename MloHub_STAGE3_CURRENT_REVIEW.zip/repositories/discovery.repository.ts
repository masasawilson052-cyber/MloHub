/**
 * ============================================================================
 * MLOHUB DISCOVERY REPOSITORY
 * ============================================================================
 * Dispatches food discovery queries to the PostgreSQL RPC search_food_discovery.
 * Provides a high-fidelity local fallback for offline development & tests.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DiscoveryQuery, DishDiscoveryResult, FreshnessTier } from '../types/discovery';
import { calculateFreshnessScore } from '../utils/formatters';
import { computeCompositeScore, calculateRelevanceScore, calculateDistanceScore, calculatePriceScore, calculateRatingScore, calculateFreshnessFromTier, calculateAvailabilityScore } from '../config/discoveryRanking';
import { runtimeConfig } from '../lib/runtimeConfig';
import { DEMO_RESTAURANTS } from '../demo/fixtures/restaurants';
import { MloHubDB } from '../db';

export class DiscoveryRepository {
  /**
   * Maps a raw SQL RPC row from search_food_discovery into a typed DishDiscoveryResult.
   */
  private static mapRpcRowToResult(row: any): DishDiscoveryResult {
    const freshness = calculateFreshnessScore(
      row.last_price_verified_at || row.last_availability_verified_at || row.last_menu_verified_at
    );

    return {
      menuItemId: row.menu_item_id,
      dishName: row.dish_name,
      dishNameSw: row.dish_name_sw,
      description: row.description,
      descriptionSw: row.description_sw,
      imageUrl: row.image_url,

      restaurantId: row.restaurant_id,
      restaurantName: row.restaurant_name,
      restaurantLogo: row.restaurant_logo,
      cuisineType: row.cuisine_type,
      branchId: row.branch_id || `br-${row.restaurant_id}`,
      branchName: row.branch_name || row.restaurant_name,
      neighborhood: row.neighborhood || 'Dar es Salaam',
      address: row.address,

      priceTzs: Number(row.price_tzs) || 0,
      basePriceTzs: Number(row.base_price_tzs) || Number(row.price_tzs) || 0,
      currency: 'TZS',
      distanceKm: Number(row.distance_km) || 1.0,

      restaurantRating: Number(row.restaurant_rating) || 4.8,
      reviewCount: Number(row.review_count) || 25,
      isAvailable: row.is_available ?? true,
      stockStatus: row.stock_status || 'IN_STOCK',
      isOpenNow: row.is_open_now ?? true,
      openingHoursSummary: row.opening_hours_summary || '08:00 AM - 10:00 PM',

      lastMenuVerifiedAt: row.last_menu_verified_at,
      lastPriceVerifiedAt: row.last_price_verified_at,
      lastAvailabilityVerifiedAt: row.last_availability_verified_at,
      freshnessScore: freshness.score,
      freshnessTier: (row.freshness_tier as FreshnessTier) || freshness.tier,
      freshnessLabel: row.freshness_label || freshness.label,

      scores: {
        relevanceScore: Number(row.relevance_rank) || 80,
        distanceScore: 80,
        priceScore: 80,
        ratingScore: 90,
        freshnessScore: freshness.score,
        availabilityScore: row.is_available ? 95 : 0,
        overallScore: Number(row.relevance_rank) || 80,
      },
    };
  }

  /**
   * Executes food discovery search.
   */
  public static async searchDishes(query: DiscoveryQuery): Promise<DishDiscoveryResult[]> {
    // 1. Live Supabase PostgreSQL RPC Execution
    if (isSupabaseConfigured()) {
      try {
        const payload = {
          p_query: query.query || null,
          p_lat: query.latitude || null,
          p_lng: query.longitude || null,
          p_neighborhood: query.neighborhood || null,
          p_max_distance_km: query.maxDistanceKm || 10.0,
          p_min_price: query.minPriceTzs || null,
          p_max_price: query.maxPriceTzs || null,
          p_min_rating: query.minRating || null,
          p_open_now: query.openNow || null,
          p_available_only: query.availableOnly ?? true,
          p_cuisine_types: query.cuisineTypes && query.cuisineTypes.length > 0 ? query.cuisineTypes : null,
          p_dietary_tags: query.dietaryTags && query.dietaryTags.length > 0 ? query.dietaryTags : null,
          p_sort: query.sortBy || 'RECOMMENDED',
          p_limit: query.limit || 20,
          p_offset: query.offset || 0,
        };

        const { data, error } = await supabase.rpc('search_food_discovery', payload);
        if (!error && Array.isArray(data)) {
          return data.map(this.mapRpcRowToResult);
        }
        if (error) {
          console.warn('DiscoveryRepository: Supabase RPC returned error:', error.message);
          if (!runtimeConfig.allowLocalDataFallbacks) {
            throw error;
          }
        }
      } catch (err) {
        console.warn('DiscoveryRepository: Supabase RPC exception:', err);
        if (!runtimeConfig.allowLocalDataFallbacks) {
          throw err;
        }
      }
    }

    // 2. High-Fidelity Local / Mock Fallback Execution (TEST / DEMO ONLY)
    if (runtimeConfig.allowLocalDataFallbacks) {
      return this.searchDishesLocalFallback(query);
    }

    if (runtimeConfig.requiresRealSupabase && !isSupabaseConfigured()) {
      throw new Error(`Supabase is required in ${runtimeConfig.environmentLabel}. Local fallback is forbidden.`);
    }

    return [];
  }

  /**
   * Deterministic local fallback providing identical business logic for tests and offline usage.
   */
  public static searchDishesLocalFallback(query: DiscoveryQuery): DishDiscoveryResult[] {
    const db = MloHubDB.getSnapshot();
    const restaurantsSource = (db.restaurants && db.restaurants.length > 0) ? db.restaurants : (DEMO_RESTAURANTS as any[]);
    const q = (query.query || '').trim().toLowerCase();

    const allDishes: DishDiscoveryResult[] = [];

    // Reference location (Default: Mikocheni B coordinates)
    const refLat = query.latitude || -6.7645;
    const refLng = query.longitude || 39.2450;

    for (const rest of restaurantsSource) {
      if (rest.is_active === false || rest.verificationStatus === 'SUSPENDED') continue;

      const restLat = rest.lat || -6.7645;
      const restLng = rest.lng || 39.2450;

      // Haversine calculation
      const dLat = ((restLat - refLat) * Math.PI) / 180;
      const dLng = ((restLng - refLng) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((refLat * Math.PI) / 180) *
          Math.cos((restLat * Math.PI) / 180) *
          Math.sin(dLng / 2) *
          Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const calcDistance = Math.round(6371 * c * 10) / 10;

      const menuList = rest.menu || [];

      for (const item of menuList) {
        const dishNameEn = item.name || item.nameEn || 'Special Dish';
        const dishNameSw = item.nameSw || dishNameEn;
        const descEn = item.desc || item.description || '';
        const price = item.priceNum || item.priceTzs || (parseInt(String(item.price || '0').replace(/[^0-9]/g, '')) || 10000);
        const isAvailable = item.isAvailable ?? true;

        // Freshness verification timestamps (staggered for realistic demo)
        let verifiedDate = rest.last_menu_verified_at || item.last_price_verified_at;
        if (!verifiedDate) {
          // Deterministic synthetic timestamp based on item id
          if (item.id === 'mab-1' || item.id === 'mab-2') {
            verifiedDate = new Date(Date.now() - 2 * 3600 * 1000).toISOString(); // 2h ago
          } else if (item.id.includes('bh-') || item.id.includes('km-1')) {
            verifiedDate = new Date(Date.now() - 5 * 3600 * 1000).toISOString(); // Today
          } else {
            verifiedDate = new Date(Date.now() - 26 * 3600 * 1000).toISOString(); // Yesterday
          }
        }

        const freshness = calculateFreshnessScore(verifiedDate);

        // Calculate scores
        const relevance = calculateRelevanceScore({
          query: q,
          dishName: dishNameEn,
          dishNameSw,
          description: descEn,
          restaurantName: rest.name,
          cuisineType: rest.cuisine,
        });

        const distScore = calculateDistanceScore(calcDistance, query.maxDistanceKm || 5);
        const priceScore = calculatePriceScore({ priceTzs: price, budgetTzs: query.maxPriceTzs });
        const ratingScore = calculateRatingScore(rest.rating || 4.8, rest.reviews || 40);
        const freshScore = calculateFreshnessFromTier(freshness.tier);
        const availScore = calculateAvailabilityScore({ isAvailable, stockStatus: 'IN_STOCK', isOpenNow: rest.isOpen ?? true });

        const composite = computeCompositeScore({
          relevanceScore: relevance,
          distanceScore: distScore,
          priceScore,
          ratingScore,
          freshnessScore: freshScore,
          availabilityScore: availScore,
        });

        allDishes.push({
          menuItemId: item.id,
          dishName: dishNameEn,
          dishNameSw,
          description: descEn,
          imageUrl: item.photoUrl || (rest as any).foodSpotPhotos?.[0] || '',
          restaurantId: rest.id,
          restaurantName: rest.name,
          restaurantLogo: (rest as any).logoUrl,
          cuisineType: rest.cuisine,
          branchId: `branch-${rest.id}-main`,
          branchName: `${rest.name} - ${rest.neighborhood || 'Main Branch'}`,
          neighborhood: rest.neighborhood || 'Mikocheni',
          address: rest.address,
          priceTzs: price,
          basePriceTzs: price,
          currency: 'TZS',
          distanceKm: calcDistance,
          restaurantRating: rest.rating || 4.8,
          reviewCount: rest.reviews || 50,
          isAvailable,
          stockStatus: 'IN_STOCK',
          isOpenNow: rest.isOpen ?? true,
          openingHoursSummary: '08:00 AM - 10:00 PM',
          lastMenuVerifiedAt: verifiedDate,
          lastPriceVerifiedAt: verifiedDate,
          freshnessScore: freshness.score,
          freshnessTier: freshness.tier,
          freshnessLabel: freshness.label,
          scores: composite,
        });
      }
    }

    // Apply filters
    let results = allDishes.filter((d) => {
      // Available only
      if (query.availableOnly && !d.isAvailable) return false;

      // Price filters
      if (query.minPriceTzs && d.priceTzs < query.minPriceTzs) return false;
      if (query.maxPriceTzs && d.priceTzs > query.maxPriceTzs) return false;

      // Rating filter
      if (query.minRating && d.restaurantRating < query.minRating) return false;

      // Open now filter
      if (query.openNow && d.isOpenNow !== true) return false;

      // Distance filter
      if (query.maxDistanceKm && d.distanceKm > query.maxDistanceKm) return false;

      // Neighborhood filter
      if (query.neighborhood && query.neighborhood !== 'All') {
        const target = query.neighborhood.toLowerCase();
        const matchesNeighborhood =
          d.neighborhood.toLowerCase().includes(target) ||
          (d.address && d.address.toLowerCase().includes(target));
        if (!matchesNeighborhood) return false;
      }

      // Query text filter
      if (q) {
        return (d.scores?.relevanceScore || 0) >= 30;
      }

      return true;
    });

    // Apply sorting
    const sortBy = query.sortBy || 'RECOMMENDED';
    results.sort((a, b) => {
      if (sortBy === 'NEAREST') return a.distanceKm - b.distanceKm;
      if (sortBy === 'CHEAPEST') return a.priceTzs - b.priceTzs;
      if (sortBy === 'HIGHEST_RATED') return b.restaurantRating - a.restaurantRating;
      if (sortBy === 'FRESHEST') return b.freshnessScore - a.freshnessScore;
      if (sortBy === 'MOST_POPULAR') return b.reviewCount - a.reviewCount;
      // RECOMMENDED
      return (b.scores?.overallScore || 0) - (a.scores?.overallScore || 0);
    });

    // Pagination
    const offset = query.offset || 0;
    const limit = query.limit || 20;
    return results.slice(offset, offset + limit);
  }
}
