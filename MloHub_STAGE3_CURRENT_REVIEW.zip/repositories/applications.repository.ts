import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { RestaurantApplication } from '../types/domain';

export class ApplicationRepository {
  private static mapRowToApplication(row: any): RestaurantApplication {
    return {
      id: row.id,
      applicantUserId: row.applicant_user_id,
      businessName: row.business_name,
      ownerName: row.owner_name,
      ownerPhone: row.owner_phone,
      ownerEmail: row.owner_email,
      cuisineType: row.cuisine_type || 'Swahili',
      neighborhood: row.neighborhood || 'Mikocheni',
      address: row.address || 'Dar es Salaam',
      businessType: row.business_type,
      hasTinOrLicense: row.has_tin_or_license ?? false,
      tinNumber: row.tin_number,
      licenseNumber: row.business_license_number,
      status: row.status || 'PENDING',
      rejectionReason: row.notes,
      notes: row.notes,
      reviewedBy: row.reviewed_by,
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || new Date().toISOString(),
    };
  }

  public static async listAll(status?: string): Promise<RestaurantApplication[]> {
    if (!isSupabaseConfigured()) return [];

    let query = supabase.from('restaurant_applications').select('*');

    if (status && status !== 'ALL') {
      query = query.eq('status', status);
    }

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) {
      console.error('ApplicationRepository.listAll error:', error.message);
      throw new Error(`Failed to list applications: ${error.message}`);
    }

    return (data || []).map(this.mapRowToApplication);
  }

  public static async getById(id: string): Promise<RestaurantApplication | null> {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('restaurant_applications')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      console.error(`ApplicationRepository.getById(${id}) error:`, error.message);
      throw new Error(`Failed to find application: ${error.message}`);
    }

    return data ? this.mapRowToApplication(data) : null;
  }

  public static async submit(app: Partial<RestaurantApplication>): Promise<RestaurantApplication> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const row = {
      id: app.id || `app_${Date.now()}`,
      business_name: app.businessName,
      owner_name: app.ownerName,
      owner_phone: app.ownerPhone,
      owner_email: app.ownerEmail,
      cuisine_type: app.cuisineType || 'Swahili',
      neighborhood: app.neighborhood || 'Mikocheni',
      address: app.address || 'Dar es Salaam',
      has_tin_or_license: app.hasTinOrLicense ?? false,
      tin_number: app.tinNumber,
      status: 'PENDING',
      notes: app.notes,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('restaurant_applications')
      .insert(row)
      .select()
      .single();

    if (error) {
      console.error('ApplicationRepository.submit error:', error.message);
      throw new Error(`Failed to submit application: ${error.message}`);
    }

    return this.mapRowToApplication(data);
  }

  public static async updateStatus(
    id: string,
    status: 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED',
    reviewedBy: string,
    rejectionReason?: string
  ): Promise<RestaurantApplication> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    // Call privileged RPC for approvals/rejections
    if (status === 'APPROVED') {
      try {
        const { error: rpcError } = await supabase.rpc('approve_restaurant_application', { p_application_id: id });
        if (!rpcError) {
          const app = await this.getById(id);
          if (app) return app;
        }
      } catch (e) {
        console.warn('Notice: approve_restaurant_application RPC fallback to update:', e);
      }
    } else if (status === 'REJECTED') {
      try {
        const { error: rpcError } = await supabase.rpc('reject_restaurant_application', {
          p_application_id: id,
          p_reason: rejectionReason || 'Requirements not met',
        });
        if (!rpcError) {
          const app = await this.getById(id);
          if (app) return app;
        }
      } catch (e) {
        console.warn('Notice: reject_restaurant_application RPC fallback to update:', e);
      }
    }

    const updates: any = {
      status,
      reviewed_by: reviewedBy,
      updated_at: new Date().toISOString(),
    };
    if (rejectionReason) {
      updates.notes = rejectionReason;
    }

    const { data, error } = await supabase
      .from('restaurant_applications')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error(`ApplicationRepository.updateStatus(${id}) error:`, error.message);
      throw new Error(`Failed to update application status: ${error.message}`);
    }

    return this.mapRowToApplication(data);
  }
}
