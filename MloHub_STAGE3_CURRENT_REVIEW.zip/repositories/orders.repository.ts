import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Order, OrderItem, OrderStatus, PaymentStatus } from '../types/domain';

export class OrderRepository {
  private static mapRowToOrder(row: any, items?: OrderItem[]): Order {
    return {
      id: row.id,
      orderNumber: row.order_number,
      customerId: row.user_id,
      restaurantId: row.restaurant_id,
      restaurantName: row.restaurants?.name || row.restaurant_name || row.restaurantName || undefined,
      branchId: row.branch_id,
      status: row.status,
      paymentStatus: row.payment_status || 'PENDING',
      subtotalTzs: row.subtotal_tzs || 0,
      serviceFeeTzs: row.service_fee_tzs || 0,
      deliveryFeeTzs: row.delivery_fee_tzs || 0,
      totalTzs: row.total_tzs || 0,
      currency: 'TZS',
      fulfillmentType: row.dining_option || 'Delivery',
      deliveryAddress: row.delivery_address,
      specialInstructions: row.special_instructions,
      estimatedPrepMinutes: row.estimated_prep_minutes || 30,
      acceptedAt: row.accepted_at,
      readyAt: row.ready_at,
      completedAt: row.completed_at,
      cancelledAt: row.cancelled_at,
      cancellationReason: row.cancellation_reason,
      items: items || (row.order_items || []).map(this.mapRowToOrderItem),
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || new Date().toISOString(),
    };
  }

  private static mapRowToOrderItem(row: any): OrderItem {
    return {
      id: row.id,
      orderId: row.order_id,
      menuItemId: row.menu_item_id,
      itemNameSnapshot: row.item_name_snapshot || row.item_name || 'Dish',
      priceSnapshot: row.price_snapshot || row.unit_price_tzs || 0,
      quantity: row.quantity || 1,
      subtotal: row.total_price_tzs || ((row.unit_price_tzs || 0) * (row.quantity || 1)),
      specialNotes: row.special_notes,
      createdAt: row.created_at || new Date().toISOString(),
    };
  }

  public static async createOrder(order: Partial<Order>, items: Partial<OrderItem>[]): Promise<Order> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    // 1. Preferred Production Path: Trusted Server-Side Order Pricing via PostgreSQL RPC
    if (order.branchId) {
      try {
        const rpcPayload = {
          p_branch_id: order.branchId,
          p_items: items.map((i) => ({
            menu_item_id: i.menuItemId,
            quantity: i.quantity || 1,
            special_notes: i.specialNotes || null,
          })),
          p_fulfillment_type: order.fulfillmentType || 'Delivery',
          p_delivery_address: order.deliveryAddress || null,
          p_special_instructions: order.specialInstructions || null,
        };

        const { data: rpcResult, error: rpcError } = await supabase.rpc('create_order_secure', rpcPayload);
        if (!rpcError && rpcResult?.order_id) {
          const loadedOrder = await this.getOrderById(rpcResult.order_id);
          if (loadedOrder) return loadedOrder;
        }
      } catch (e) {
        console.warn('Notice: create_order_secure RPC fallback to direct insert:', e);
      }
    }

    const orderId = order.id || `ord_${Date.now()}`;
    const orderNumber = order.orderNumber || `MLO-${Date.now().toString().slice(-4)}`;

    // 2. Direct Table Insert (Fallback / Direct creation)
    const orderRow = {
      id: orderId,
      order_number: orderNumber,
      user_id: order.customerId,
      restaurant_id: order.restaurantId,
      branch_id: order.branchId,
      status: order.status || 'PENDING',
      payment_status: order.paymentStatus || 'PENDING',
      subtotal_tzs: order.subtotalTzs || 0,
      service_fee_tzs: order.serviceFeeTzs || 1500,
      delivery_fee_tzs: order.deliveryFeeTzs || 0,
      total_tzs: order.totalTzs || 0,
      dining_option: order.fulfillmentType || 'Delivery',
      delivery_address: order.deliveryAddress,
      special_instructions: order.specialInstructions,
      estimated_prep_minutes: order.estimatedPrepMinutes || 30,
      updated_at: new Date().toISOString(),
    };

    const { data: insertedOrder, error: orderError } = await supabase
      .from('orders')
      .insert(orderRow)
      .select()
      .single();

    if (orderError) {
      console.error('OrderRepository.createOrder error:', orderError.message);
      throw new Error(`Failed to create order: ${orderError.message}`);
    }

    // Insert order items with snapshots
    const itemRows = items.map((item, idx) => ({
      id: item.id || `item_ord_${Date.now()}_${idx}`,
      order_id: orderId,
      menu_item_id: item.menuItemId,
      item_name: item.itemNameSnapshot || 'Item',
      item_name_snapshot: item.itemNameSnapshot || 'Item',
      unit_price_tzs: item.priceSnapshot || 0,
      price_snapshot: item.priceSnapshot || 0,
      quantity: item.quantity || 1,
      total_price_tzs: item.subtotal || ((item.priceSnapshot || 0) * (item.quantity || 1)),
      special_notes: item.specialNotes,
    }));

    const { data: insertedItems, error: itemsError } = await supabase
      .from('order_items')
      .insert(itemRows)
      .select();

    if (itemsError) {
      console.error('OrderRepository.createOrder items error:', itemsError.message);
      throw new Error(`Failed to save order line items: ${itemsError.message}`);
    }

    return this.mapRowToOrder(
      insertedOrder,
      (insertedItems || []).map(this.mapRowToOrderItem)
    );
  }

  public static async getOrderById(id: string): Promise<Order | null> {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('orders')
      .select('*, order_items(*), restaurants(name)')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      console.error(`OrderRepository.getOrderById(${id}) error:`, error.message);
      throw new Error(`Failed to find order: ${error.message}`);
    }

    return data ? this.mapRowToOrder(data) : null;
  }

  public static async listOrdersForCustomer(customerId: string): Promise<Order[]> {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('orders')
      .select('*, order_items(*), restaurants(name)')
      .eq('user_id', customerId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error(`OrderRepository.listOrdersForCustomer error:`, error.message);
      throw new Error(`Failed to list customer orders: ${error.message}`);
    }

    return (data || []).map((row) => this.mapRowToOrder(row));
  }

  public static async listByCustomer(customerId: string): Promise<Order[]> {
    return this.listOrdersForCustomer(customerId);
  }

  public static async listOrdersForRestaurant(
    restaurantId: string,
    status?: OrderStatus
  ): Promise<Order[]> {
    if (!isSupabaseConfigured()) return [];

    let query = supabase
      .from('orders')
      .select('*, order_items(*), restaurants(name)')
      .eq('restaurant_id', restaurantId);

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) {
      console.error(`OrderRepository.listOrdersForRestaurant error:`, error.message);
      throw new Error(`Failed to list restaurant orders: ${error.message}`);
    }

    return (data || []).map((row) => this.mapRowToOrder(row));
  }

  public static async listAll(options?: { status?: OrderStatus; limit?: number }): Promise<Order[]> {
    if (!isSupabaseConfigured()) return [];

    let query = supabase.from('orders').select('*, order_items(*), restaurants(name)');
    if (options?.status) {
      query = query.eq('status', options.status);
    }
    const { data, error } = await query
      .order('created_at', { ascending: false })
      .limit(options?.limit || 100);

    if (error) {
      console.error('OrderRepository.listAll error:', error.message);
      return [];
    }

    return (data || []).map((row) => this.mapRowToOrder(row));
  }

  public static async updateStatus(

    orderId: string,
    status: OrderStatus,
    cancellationReason?: string
  ): Promise<Order> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const updates: any = {
      status,
      updated_at: new Date().toISOString(),
    };

    if (status === 'ACCEPTED') updates.accepted_at = new Date().toISOString();
    if (status === 'READY') updates.ready_at = new Date().toISOString();
    if (status === 'COMPLETED') updates.completed_at = new Date().toISOString();
    if (status === 'CANCELLED' || status === 'REJECTED') {
      updates.cancelled_at = new Date().toISOString();
      if (cancellationReason) updates.cancellation_reason = cancellationReason;
    }

    const { data, error } = await supabase
      .from('orders')
      .update(updates)
      .eq('id', orderId)
      .select('*, order_items(*)')
      .single();

    if (error) {
      console.error(`OrderRepository.updateStatus(${orderId}) error:`, error.message);
      throw new Error(`Failed to update order status: ${error.message}`);
    }

    return this.mapRowToOrder(data);
  }

  public static async updatePaymentStatus(orderId: string, paymentStatus: PaymentStatus): Promise<Order> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const { data, error } = await supabase
      .from('orders')
      .update({
        payment_status: paymentStatus,
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId)
      .select('*, order_items(*)')
      .single();

    if (error) {
      console.error(`OrderRepository.updatePaymentStatus(${orderId}) error:`, error.message);
      throw new Error(`Failed to update payment status: ${error.message}`);
    }

    return this.mapRowToOrder(data);
  }
}
