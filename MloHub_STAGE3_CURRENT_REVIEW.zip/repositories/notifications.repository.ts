import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Notification } from '../types/domain';

export class NotificationRepository {
  private static mapRowToNotification(row: any): Notification {
    return {
      id: row.id,
      userId: row.user_id,
      type: row.type,
      category: row.category || 'ORDER',
      titleEn: row.title_en,
      titleSw: row.title_sw,
      messageEn: row.message_en,
      messageSw: row.message_sw,
      isRead: row.is_read ?? false,
      orderId: row.order_id,
      restaurantId: row.restaurant_id,
      actionType: row.action_type,
      payload: row.data || {},
      createdAt: row.created_at || new Date().toISOString(),
    };
  }

  public static async listForUser(userId: string): Promise<Notification[]> {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error(`NotificationRepository.listForUser(${userId}) error:`, error.message);
      throw new Error(`Failed to load notifications: ${error.message}`);
    }

    return (data || []).map(this.mapRowToNotification);
  }

  public static async listAll(limit: number = 100): Promise<Notification[]> {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('NotificationRepository.listAll error:', error.message);
      return [];
    }

    return (data || []).map(this.mapRowToNotification);
  }

  public static async markAsRead(id: string): Promise<void> {
    if (!isSupabaseConfigured()) return;

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', id);

    if (error) {
      console.error(`NotificationRepository.markAsRead(${id}) error:`, error.message);
    }
  }

  public static async createNotification(notif: Partial<Notification>): Promise<Notification> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const row = {
      id: notif.id || `notif_${Date.now()}`,
      user_id: notif.userId,
      type: notif.type || 'SYSTEM',
      category: notif.category || 'ORDER',
      title_en: notif.titleEn || 'Notification',
      title_sw: notif.titleSw || 'Taarifa',
      message_en: notif.messageEn || '',
      message_sw: notif.messageSw || '',
      is_read: false,
      order_id: notif.orderId,
      restaurant_id: notif.restaurantId,
      action_type: notif.actionType,
      data: notif.payload || {},
    };

    const { data, error } = await supabase
      .from('notifications')
      .insert(row)
      .select()
      .single();

    if (error) {
      console.error('NotificationRepository.createNotification error:', error.message);
      throw new Error(`Failed to create notification: ${error.message}`);
    }

    return this.mapRowToNotification(data);
  }
}
