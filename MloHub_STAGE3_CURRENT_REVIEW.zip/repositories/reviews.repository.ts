import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Review } from '../types/domain';

export class ReviewRepository {
  private static mapRowToReview(row: any): Review {
    return {
      id: row.id,
      customerId: row.user_id,
      restaurantId: row.restaurant_id,
      orderId: row.order_id,
      overallRating: row.rating || 5,
      comment: row.comment,
      status: 'PUBLISHED',
      createdAt: row.created_at || new Date().toISOString(),
    };
  }

  public static async listForRestaurant(restaurantId: string): Promise<Review[]> {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error(`ReviewRepository.listForRestaurant error:`, error.message);
      throw new Error(`Failed to load reviews: ${error.message}`);
    }

    return (data || []).map(this.mapRowToReview);
  }

  public static async create(review: Partial<Review>): Promise<Review> {
    if (!isSupabaseConfigured()) {
      throw new Error('Supabase client is not configured.');
    }

    const row = {
      id: review.id || `rev_${Date.now()}`,
      user_id: review.customerId,
      restaurant_id: review.restaurantId,
      order_id: review.orderId,
      rating: review.overallRating || 5,
      comment: review.comment,
    };

    const { data, error } = await supabase
      .from('reviews')
      .insert(row)
      .select()
      .single();

    if (error) {
      console.error('ReviewRepository.create error:', error.message);
      throw new Error(`Failed to submit review: ${error.message}`);
    }

    return this.mapRowToReview(data);
  }
}
