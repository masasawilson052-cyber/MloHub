﻿-- ============================================================================
-- MLOHUB PACK 2 MINIMAL VERIFICATION SEED
-- Purpose: verify migrations, FK integrity, auth/profile bootstrap, and RLS
-- Rich/demo fixtures are kept separately in seed.full_legacy.pack2bak
-- ============================================================================

INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at
)
VALUES
(
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'authenticated',
    'authenticated',
    'pack2.customer@mlohub.local',
    '',
    NOW(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"full_name":"Pack2 Customer","phone":"+255700000001","account_type":"CUSTOMER"}'::jsonb,
    NOW(),
    NOW()
),
(
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000002',
    'authenticated',
    'authenticated',
    'pack2.owner@mlohub.local',
    '',
    NOW(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"full_name":"Pack2 Owner","phone":"+255700000002","account_type":"RESTAURANT_OWNER"}'::jsonb,
    NOW(),
    NOW()
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.restaurants (
    id,
    owner_id,
    name,
    slug,
    cuisine,
    description,
    seller_tier,
    rating,
    reviews_count,
    min_price_tzs,
    max_price_tzs,
    address,
    neighborhood,
    region_city,
    distance_km,
    estimated_prep_time_minutes,
    is_open,
    is_verified,
    verification_status,
    payout_phone_number,
    payout_provider,
    opening_hours,
    closing_hours,
    specialty,
    specialist_badge,
    tags
)
VALUES (
    'pack2-test-restaurant',
    '00000000-0000-0000-0000-000000000002',
    'Pack2 Test Restaurant',
    'pack2-test-restaurant',
    'Test Cuisine',
    'Local verification fixture only.',
    'BASIC_SELLER',
    1,
    0,
    5000,
    20000,
    'Dar es Salaam',
    'Mikocheni',
    'Dar es Salaam',
    1.0,
    20,
    TRUE,
    FALSE,
    'VERIFIED',
    '+255700000002',
    'M-Pesa',
    '08:00 AM',
    '08:00 PM',
    'Test Dish',
    'TEST',
    ARRAY['Pack2']
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.restaurant_branches (
    id,
    restaurant_id,
    name,
    address,
    region,
    district,
    ward,
    latitude,
    longitude,
    phone,
    is_active
)
VALUES (
    '10000000-0000-0000-0000-000000000001',
    'pack2-test-restaurant',
    'Pack2 Main Branch',
    'Dar es Salaam',
    'Dar es Salaam',
    NULL,
    'Mikocheni',
    -6.77,
    39.24,
    '+255700000002',
    TRUE
)
ON CONFLICT (id) DO NOTHING;


