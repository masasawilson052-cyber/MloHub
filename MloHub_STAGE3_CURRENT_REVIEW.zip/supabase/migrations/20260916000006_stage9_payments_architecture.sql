-- ==============================================================================
-- MLOHUB STAGE 9: SERVER-DRIVEN TANZANIAN PAYMENT ARCHITECTURE
-- ClickPesa Primary, Selcom Secondary, Append-Only Payment Ledger & Refunds
-- ==============================================================================

-- 1. Enhance `payments` table
ALTER TABLE IF EXISTS public.payments
  ADD COLUMN IF NOT EXISTS provider_transaction_id TEXT,
  ADD COLUMN IF NOT EXISTS merchant_reference TEXT,
  ADD COLUMN IF NOT EXISTS idempotency_key TEXT,
  ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS failed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS refunded_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS failure_reason TEXT,
  ADD COLUMN IF NOT EXISTS gateway_response JSONB DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}'::jsonb;

-- Ensure uniqueness constraints for idempotency and references
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'payments_merchant_reference_key'
  ) THEN
    ALTER TABLE public.payments ADD CONSTRAINT payments_merchant_reference_key UNIQUE (merchant_reference);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'payments_idempotency_key_key'
  ) THEN
    ALTER TABLE public.payments ADD CONSTRAINT payments_idempotency_key_key UNIQUE (idempotency_key);
  END IF;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_payments_merchant_reference ON public.payments(merchant_reference);
CREATE INDEX IF NOT EXISTS idx_payments_idempotency_key ON public.payments(idempotency_key);
CREATE INDEX IF NOT EXISTS idx_payments_provider_tx_id ON public.payments(provider_transaction_id);

-- 2. Create `payment_events` table (Append-Only Financial Ledger)
CREATE TABLE IF NOT EXISTS public.payment_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id VARCHAR(80) REFERENCES public.payments(id) ON DELETE CASCADE,
  event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'clickpesa',
  status TEXT NOT NULL,
  amount_tzs NUMERIC(12, 2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TZS',
  merchant_reference TEXT,
  provider_reference TEXT,
  raw_payload JSONB DEFAULT '{}'::jsonb,
  actor_type TEXT NOT NULL DEFAULT 'SYSTEM', -- 'GATEWAY_WEBHOOK' | 'CUSTOMER' | 'ADMIN' | 'SYSTEM'
  actor_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS idx_payment_events_payment_id ON public.payment_events(payment_id);
CREATE INDEX IF NOT EXISTS idx_payment_events_event_id ON public.payment_events(event_id);
CREATE INDEX IF NOT EXISTS idx_payment_events_merchant_ref ON public.payment_events(merchant_reference);

-- 3. Create `refunds` table (Tracking full & partial refunds)
CREATE TABLE IF NOT EXISTS public.refunds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id VARCHAR(80) NOT NULL REFERENCES public.payments(id) ON DELETE CASCADE,
  refund_reference TEXT NOT NULL UNIQUE,
  amount_tzs NUMERIC(12, 2) NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING', -- 'PENDING' | 'REFUNDED' | 'FAILED'
  authorized_by UUID REFERENCES auth.users(id),
  gateway_response JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS idx_refunds_payment_id ON public.refunds(payment_id);
CREATE INDEX IF NOT EXISTS idx_refunds_reference ON public.refunds(refund_reference);

-- 4. Enable Row Level Security (RLS)
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.refunds ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies for `payments`
DROP POLICY IF EXISTS "Customers can view own payments" ON public.payments;
CREATE POLICY "Customers can view own payments"
  ON public.payments
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Restaurant staff can view payments for their restaurant" ON public.payments;
CREATE POLICY "Restaurant staff can view payments for their restaurant"
  ON public.payments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurant_members rm
      WHERE rm.user_id = auth.uid()
        AND rm.restaurant_id = public.payments.restaurant_id
        AND rm.status = 'ACTIVE'
    )
  );

DROP POLICY IF EXISTS "Admins have full access to payments" ON public.payments;
CREATE POLICY "Admins have full access to payments"
  ON public.payments
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND (p.role IN ('ADMIN'::user_role_enum, 'SUPER_ADMIN'::user_role_enum) OR 'ADMIN'::user_role_enum = ANY(p.roles) OR 'SUPER_ADMIN'::user_role_enum = ANY(p.roles))
    )
  );

-- 6. RLS Policies for `payment_events` (Append-Only Ledger: NO UPDATE or DELETE for non-admins)
DROP POLICY IF EXISTS "Customers can view own payment events" ON public.payment_events;
CREATE POLICY "Customers can view own payment events"
  ON public.payment_events
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.payments p
      WHERE p.id = public.payment_events.payment_id
        AND p.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Restaurant staff can view payment events for their restaurant" ON public.payment_events;
CREATE POLICY "Restaurant staff can view payment events for their restaurant"
  ON public.payment_events
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.payments p
      JOIN public.restaurant_members rm ON rm.restaurant_id = p.restaurant_id
      WHERE p.id = public.payment_events.payment_id
        AND rm.user_id = auth.uid()
        AND rm.status = 'ACTIVE'
    )
  );

DROP POLICY IF EXISTS "Admins have full access to payment events" ON public.payment_events;
CREATE POLICY "Admins have full access to payment events"
  ON public.payment_events
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND (p.role IN ('ADMIN'::user_role_enum, 'SUPER_ADMIN'::user_role_enum) OR 'ADMIN'::user_role_enum = ANY(p.roles) OR 'SUPER_ADMIN'::user_role_enum = ANY(p.roles))
    )
  );

-- 7. RLS Policies for `refunds`
DROP POLICY IF EXISTS "Customers can view refunds for own payments" ON public.refunds;
CREATE POLICY "Customers can view refunds for own payments"
  ON public.refunds
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.payments p
      WHERE p.id = public.refunds.payment_id
        AND p.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Admins have full access to refunds" ON public.refunds;
CREATE POLICY "Admins have full access to refunds"
  ON public.refunds
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND (p.role IN ('ADMIN'::user_role_enum, 'SUPER_ADMIN'::user_role_enum) OR 'ADMIN'::user_role_enum = ANY(p.roles) OR 'SUPER_ADMIN'::user_role_enum = ANY(p.roles))
    )
  );

-- 8. Immutable Ledger Guard: Prevent UPDATE or DELETE on payment_events
CREATE OR REPLACE FUNCTION public.prevent_payment_events_mutation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  RAISE EXCEPTION 'payment_events is an append-only immutable financial ledger. UPDATE and DELETE operations are strictly prohibited.';
END;
$$;

DROP TRIGGER IF EXISTS trg_prevent_payment_events_mutation ON public.payment_events;
CREATE TRIGGER trg_prevent_payment_events_mutation
  BEFORE UPDATE OR DELETE ON public.payment_events
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_payment_events_mutation();

-- 9. Authoritative Payment Confirmation RPC
-- Transitions order/reservation state and logs immutable payment event atomically
CREATE OR REPLACE FUNCTION public.confirm_payment_webhook_rpc(
  p_merchant_reference TEXT,
  p_gateway_reference TEXT,
  p_provider TEXT,
  p_collected_amount NUMERIC(12, 2),
  p_event_id TEXT,
  p_raw_payload JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_payment RECORD;
  v_order RECORD;
  v_res RECORD;
BEGIN
  -- 1. Locate payment by merchant reference or provider reference
  SELECT * INTO v_payment FROM public.payments
  WHERE merchant_reference = p_merchant_reference
     OR provider_transaction_id = p_gateway_reference
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'PAYMENT_NOT_FOUND',
      'message', 'No transaction found for merchant reference: ' || p_merchant_reference
    );
  END IF;

  -- 2. Check Idempotency: Already paid?
  IF v_payment.status = 'SUCCESS' THEN
    RETURN jsonb_build_object(
      'success', true,
      'idempotent', true,
      'payment_id', v_payment.id,
      'message', 'Payment already confirmed and processed'
    );
  END IF;

  -- 3. Verify Authoritative Amount Match
  IF p_collected_amount < v_payment.amount_tzs THEN
    -- Flag underpayment fraud attempt
    UPDATE public.payments
    SET status = 'FAILED',
        failed_at = clock_timestamp(),
        failure_reason = 'Amount mismatch: expected ' || v_payment.amount_tzs || ' TZS, received ' || p_collected_amount || ' TZS'
    WHERE id = v_payment.id;

    INSERT INTO public.payment_events (
      payment_id, event_id, event_type, provider, status, amount_tzs,
      merchant_reference, provider_reference, raw_payload, actor_type
    ) VALUES (
      v_payment.id, p_event_id, 'AMOUNT_MISMATCH', p_provider, 'FAILED', p_collected_amount,
      p_merchant_reference, p_gateway_reference, p_raw_payload, 'GATEWAY_WEBHOOK'
    );

    RETURN jsonb_build_object(
      'success', false,
      'error', 'AMOUNT_MISMATCH',
      'message', 'Collected amount does not match expected authoritative amount'
    );
  END IF;

  -- 4. Mark Payment as PAID
  UPDATE public.payments
  SET status = 'SUCCESS',
      provider_transaction_id = COALESCE(p_gateway_reference, provider_transaction_id),
      confirmed_at = clock_timestamp(),
      gateway_response = p_raw_payload
  WHERE id = v_payment.id;

  -- 5. Append to Immutable Ledger
  INSERT INTO public.payment_events (
    payment_id, event_id, event_type, provider, status, amount_tzs,
    merchant_reference, provider_reference, raw_payload, actor_type
  ) VALUES (
    v_payment.id, p_event_id, 'PAYMENT_CONFIRMED', p_provider, 'SUCCESS', p_collected_amount,
    p_merchant_reference, p_gateway_reference, p_raw_payload, 'GATEWAY_WEBHOOK'
  );

  -- 6. Lock and confirm order if linked
  IF v_payment.order_id IS NOT NULL THEN
    UPDATE public.orders
    SET 
        payment_status = 'SUCCESS',
        updated_at = clock_timestamp()
    WHERE id = v_payment.order_id;
  END IF;

  -- 7. Confirm reservation if linked
  IF v_payment.reservation_id IS NOT NULL THEN
    UPDATE public.reservations
    SET status = 'CONFIRMED',
        is_deposit_paid = true,
        deposit_amount_tzs = v_payment.amount_tzs,
        updated_at = clock_timestamp()
    WHERE id = v_payment.reservation_id;
  END IF;

  RETURN jsonb_build_object(
    'success', true,
    'payment_id', v_payment.id,
    'order_id', v_payment.order_id,
    'reservation_id', v_payment.reservation_id,
    'amount', v_payment.amount_tzs,
    'status', 'SUCCESS'
  );
END;
$$;

