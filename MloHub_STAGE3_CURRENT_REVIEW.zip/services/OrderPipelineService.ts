import { MloHubDB, CustomMealRequestEntity } from '../db';
import { RealtimeEventEngine, RealtimeEventPayload } from '../db/realtime/eventEngine';
import { MenuItemEntity } from '../db/types';
import { OrderRepository } from '../repositories/orders.repository';
import { isSupabaseConfigured } from '../lib/supabase';

export interface SubmitOrderDTO {
  userId: string;
  customerName?: string;
  customerPhone?: string;
  dishName: string;
  restaurantName?: string;
  targetRestaurantId?: string;
  specialInstructions: string;
  budgetTzs: number;
  servingsCount: string;
  diningOption: 'Delivery' | 'Dine-In' | 'Takeaway';
  neighborhood?: string;
}

export interface SubmitMenuOrderDTO {
  userId: string;
  customerName?: string;
  customerPhone?: string;
  restaurantId: string;
  items: {
    menuItemId?: string;
    name: string;
    unitPriceTzs: number;
    quantity: number;
    totalPriceTzs: number;
  }[];
  diningOption: 'Delivery' | 'Dine-In' | 'Takeaway';
  deliveryAddress?: string;
  specialInstructions?: string;
}

export interface QuoteMealDTO {
  quotedPriceTzs: number;
  estimatedDeliveryTime: string;
  inclusions: string;
  chefNotes?: string;
}

export class OrderPipelineServiceImpl {
  /**
   * Helper: Broadcast order events to Customer, Restaurant, Admin, and wildcard channel
   */
  private broadcastOrderEvent(
    eventType: string,
    orderId: string,
    customerId: string,
    restaurantId: string,
    data: any
  ) {
    const payload = {
      eventType,
      orderId,
      customerId,
      restaurantId,
      data,
    };
    // 1. Specific Customer Channel
    if (customerId) {
      RealtimeEventEngine.publish(`orders:customer:${customerId}`, payload);
    }
    // 2. Specific Restaurant Channel
    if (restaurantId) {
      RealtimeEventEngine.publish(`orders:restaurant:${restaurantId}`, payload);
    }
    // 3. Central Admin Real-time Channel
    RealtimeEventEngine.publish('orders:admin', payload);
    // 4. Wildcard Channel for all listening components
    RealtimeEventEngine.publish('orders:*', payload);
  }

  /**
   * 1. Customer places a standard menu order
   */
  async submitStandardMenuOrder(dto: SubmitMenuOrderDTO): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    const orderNumber = `MLO-${Date.now().toString().slice(-4)}`;
    const rest = MloHubDB.restaurants.getById(dto.restaurantId);
    const restaurantName = rest?.name || 'MloHub Kitchen';

    const subtotal = dto.items.reduce((sum, item) => sum + item.totalPriceTzs, 0);
    const serviceFee = 1500;
    const deliveryFee = dto.diningOption === 'Delivery' ? 2500 : 0;
    const totalTzs = subtotal + serviceFee + deliveryFee;

    const itemsSummary = dto.items.map((i) => `${i.quantity}x ${i.name}`).join(', ');

    // Decrement stock in menu items if applicable
    if (rest && rest.menu) {
      for (const item of dto.items) {
        if (item.menuItemId) {
          const menuItem = rest.menu.find((m) => m.id === item.menuItemId);
          if (menuItem && menuItem.stockQuantity !== undefined) {
            menuItem.stockQuantity = Math.max(0, menuItem.stockQuantity - item.quantity);
            if (menuItem.stockQuantity === 0) {
              menuItem.isAvailable = false;
            }
          }
        }
      }
      await MloHubDB.save();
    }

    const newOrder = await MloHubDB.customOrders.create({
      userId: dto.userId,
      dishName: itemsSummary,
      restaurantName,
      targetRestaurantId: dto.restaurantId,
      specialInstructions: dto.specialInstructions || '',
      budgetTzs: totalTzs,
      servingsCount: `${dto.items.reduce((s, i) => s + i.quantity, 0)} Items`,
      diningOption: dto.diningOption,
      status: 'Pending Confirmation',
      statusMessageEn: `Order #${orderNumber} submitted to ${restaurantName}. Awaiting kitchen acceptance.`,
      statusMessageSw: `Agizo #${orderNumber} limetumwa kwa ${restaurantName}. Linasubiri kukubaliwa na jikoni.`,
      paymentStatus: 'UNPAID',
    });

    // Customer In-App Notification
    await MloHubDB.notifications.create({
      userId: dto.userId,
      type: 'order',
      titleEn: `Order #${orderNumber} Placed!`,
      titleSw: `Agizo #${orderNumber} Limewekwa!`,
      messageEn: `Your order for "${itemsSummary}" has been sent to ${restaurantName}.`,
      messageSw: `Agizo lako la "${itemsSummary}" limetumwa kwa ${restaurantName}.`,
      data: { orderId: newOrder.id, orderNumber, restaurantId: dto.restaurantId },
    });

    // Kitchen Owner In-App Notification
    const ownerId = rest?.ownerId || 'usr-chef-amina';
    await MloHubDB.notifications.create({
      userId: ownerId,
      type: 'order',
      titleEn: `New Incoming Order: #${orderNumber}`,
      titleSw: `Agizo Jipya Jikoni: #${orderNumber}`,
      messageEn: `${dto.customerName || 'Customer'} ordered: ${itemsSummary} (TZS ${totalTzs.toLocaleString()}).`,
      messageSw: `${dto.customerName || 'Mteja'} ameagiza: ${itemsSummary} (TZS ${totalTzs.toLocaleString()}).`,
      data: { orderId: newOrder.id, orderNumber, restaurantId: dto.restaurantId },
    });

    // Real-Time Broadcast (Admin, Customer, Restaurant)
    const payload = {
      order: newOrder,
      items: dto.items,
      totalTzs,
      customer: {
        name: dto.customerName || 'Customer',
        phone: dto.customerPhone || '+255 754 000 000',
        deliveryAddress: dto.deliveryAddress || 'Mikocheni',
      },
    };

    this.broadcastOrderEvent('NEW_ORDER_PLACED', newOrder.id, dto.userId, dto.restaurantId, payload);

    return newOrder;
  }

  /**
   * 2. Customer places an advance custom meal request
   */
  async submitCustomMealOrder(dto: SubmitOrderDTO): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    const orderNumber = `MLO-${Date.now().toString().slice(-4)}`;
    const targetRestId = dto.targetRestaurantId || 'mama-amina-biryani';
    const rest = MloHubDB.restaurants.getById(targetRestId);
    const restaurantName = dto.restaurantName || rest?.name || 'Mama Amina Authentic Biryani';

    const newOrder = await MloHubDB.customOrders.create({
      userId: dto.userId,
      dishName: dto.dishName,
      restaurantName,
      targetRestaurantId: targetRestId,
      specialInstructions: dto.specialInstructions,
      budgetTzs: dto.budgetTzs,
      servingsCount: dto.servingsCount,
      diningOption: dto.diningOption,
      status: 'Pending Confirmation',
      statusMessageEn: `Submitted to ${restaurantName}. Awaiting kitchen confirmation.`,
      statusMessageSw: `Imetumwa kwa ${restaurantName}. Inasubiri uthibitisho wa jikoni.`,
      paymentStatus: 'UNPAID',
    });

    // Notifications & Realtime
    await MloHubDB.notifications.create({
      userId: dto.userId,
      type: 'order',
      titleEn: `Custom Meal #${orderNumber} Submitted!`,
      titleSw: `Ombi la Chakula #${orderNumber} Limetumwa!`,
      messageEn: `Your request for ${dto.dishName} has been sent to ${restaurantName}.`,
      messageSw: `Ombi lako la ${dto.dishName} limetumwa kwa ${restaurantName}.`,
      data: { orderId: newOrder.id, orderNumber },
    });

    const payload = {
      order: newOrder,
      customer: {
        name: dto.customerName || 'Customer',
        phone: dto.customerPhone || '+255 754 000 000',
        neighborhood: dto.neighborhood || 'Mikocheni',
      },
    };

    this.broadcastOrderEvent('NEW_ORDER_PLACED', newOrder.id, dto.userId, targetRestId, payload);

    return newOrder;
  }

  /**
   * 3. Restaurant Owner accepts order and sets estimated prep time
   */
  async acceptOrder(
    orderId: string,
    prepTimeMinutes: number = 25,
    restaurantId: string = 'mama-amina-biryani'
  ): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    if (isSupabaseConfigured()) {
      try {
        await OrderRepository.updateStatus(orderId, 'ACCEPTED');
      } catch (err) {
        // Not in Supabase orders table or already updated
      }
    }

    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) {
      if (isSupabaseConfigured()) {
        const sbOrder = await OrderRepository.getOrderById(orderId);
        if (sbOrder) {
          const payload = {
            order: sbOrder,
            prepTimeMinutes,
            status: 'Confirmed',
          };
          this.broadcastOrderEvent('ORDER_CONFIRMED', orderId, sbOrder.customerId, sbOrder.restaurantId, payload);
          return {
            id: sbOrder.id,
            userId: sbOrder.customerId,
            targetRestaurantId: sbOrder.restaurantId,
            status: 'Confirmed',
            dishName: sbOrder.items?.[0]?.itemNameSnapshot || 'Order',
            budgetTzs: sbOrder.totalTzs,
            servingsCount: '1',
            diningOption: sbOrder.fulfillmentType as any,
            specialInstructions: sbOrder.specialInstructions || '',
            paymentStatus: sbOrder.paymentStatus === 'SUCCESS' ? 'PAID' : 'UNPAID',
            orderNumber: sbOrder.orderNumber,
          } as any;
        }
      }
      throw new Error(`Order ${orderId} not found`);
    }

    const rest = MloHubDB.restaurants.getById(restaurantId);
    const restaurantName = rest?.name || existing.restaurantName;

    const updated = await MloHubDB.customOrders.update(orderId, {
      status: 'Confirmed',
      statusMessageEn: `Order accepted by ${restaurantName}. Freshly cooking now! (Estimated prep: ${prepTimeMinutes} mins)`,
      statusMessageSw: `Agizo limekubaliwa na ${restaurantName}. Linapikwa sasa hivi! (Muda uliokadiriwa: dk ${prepTimeMinutes})`,
    });

    if (!updated) throw new Error('Failed to accept order');

    // Create Notification
    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'order',
      titleEn: `Order #${existing.orderNumber} Accepted!`,
      titleSw: `Agizo #${existing.orderNumber} Limekubaliwa!`,
      messageEn: `${restaurantName} is preparing your order. Estimated ready in ${prepTimeMinutes} mins.`,
      messageSw: `${restaurantName} anakuandalia chakula chako. Kitakuwa tayari ndani ya dk ${prepTimeMinutes}.`,
      data: { orderId, prepTimeMinutes },
    });

    const payload = {
      order: updated,
      prepTimeMinutes,
      status: 'Confirmed',
    };

    this.broadcastOrderEvent('ORDER_CONFIRMED', orderId, existing.userId, restaurantId, payload);

    return updated;
  }

  /**
   * 3b. Legacy / Convenience: accept and confirm order with custom restaurant name
   */
  async acceptAndConfirmOrder(
    orderId: string,
    restaurantId: string = 'mama-amina-biryani',
    restaurantName: string = 'Mama Amina Authentic Biryani',
    prepTimeMinutes: number = 30
  ): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) throw new Error(`Order ${orderId} not found`);

    const updated = await MloHubDB.customOrders.update(orderId, {
      status: 'Confirmed',
      statusMessageEn: `Order Confirmed by ${restaurantName}. Chef is preparing your batch (Est: ${prepTimeMinutes} mins).`,
      statusMessageSw: `Agizo Limethibitishwa na ${restaurantName}. Mpishi anakuandalia mlo wako (Takribani: dk ${prepTimeMinutes}).`,
      targetRestaurantId: restaurantId,
      restaurantName,
    });

    if (!updated) throw new Error('Failed to confirm order');

    // Customer Notification
    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'order',
      titleEn: `Order #${existing.orderNumber} Confirmed!`,
      titleSw: `Agizo #${existing.orderNumber} Limethibitishwa!`,
      messageEn: `${restaurantName} has confirmed your order. Estimated prep time: ${prepTimeMinutes} mins.`,
      messageSw: `${restaurantName} amethibitisha agizo lako. Muda wa kuandaa: dk ${prepTimeMinutes}.`,
      data: { orderId, prepTimeMinutes, restaurantId },
    });

    const payload = {
      order: updated,
      prepTimeMinutes,
      status: 'Confirmed',
      restaurantName,
    };

    this.broadcastOrderEvent('ORDER_CONFIRMED', orderId, existing.userId, restaurantId, payload);

    return updated;
  }

  /**
   * 3c. Chef quotes a custom meal request
   */
  async quoteCustomMeal(
    orderId: string,
    restaurantId: string,
    restaurantName: string,
    quote: QuoteMealDTO
  ): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) throw new Error(`Order ${orderId} not found`);

    const updated = await MloHubDB.customOrders.update(orderId, {
      budgetTzs: quote.quotedPriceTzs,
      targetRestaurantId: restaurantId,
      restaurantName,
      statusMessageEn: `Quoted TZS ${quote.quotedPriceTzs.toLocaleString()} by ${restaurantName}. Delivery: ${quote.estimatedDeliveryTime}`,
      statusMessageSw: `Imekadiriwa TZS ${quote.quotedPriceTzs.toLocaleString()} na ${restaurantName}. Uwasilishaji: ${quote.estimatedDeliveryTime}`,
    });

    if (!updated) throw new Error('Failed to quote custom meal');

    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'order',
      titleEn: `New Kitchen Quote: TZS ${quote.quotedPriceTzs.toLocaleString()}`,
      titleSw: `Bei Mpya ya Jikoni: TZS ${quote.quotedPriceTzs.toLocaleString()}`,
      messageEn: `${restaurantName} quoted TZS ${quote.quotedPriceTzs.toLocaleString()} for your custom feast.`,
      messageSw: `${restaurantName} amekadiria TZS ${quote.quotedPriceTzs.toLocaleString()} kwa agizo lako maalum.`,
      data: { orderId, quote, restaurantId },
    });

    this.broadcastOrderEvent('QUOTE_OFFERED', orderId, existing.userId, restaurantId, { quote, order: updated });

    return updated;
  }

  /**
   * 4. Restaurant Owner rejects order
   */
  async rejectOrder(
    orderId: string,
    reason: string = 'Kitchen at maximum capacity'
  ): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    if (isSupabaseConfigured()) {
      try {
        await OrderRepository.updateStatus(orderId, 'CANCELLED', reason);
      } catch (err) {
        // Not in Supabase orders table or already updated
      }
    }

    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) {
      if (isSupabaseConfigured()) {
        const sbOrder = await OrderRepository.getOrderById(orderId);
        if (sbOrder) {
          const payload = { order: sbOrder, reason, status: 'Cancelled' };
          this.broadcastOrderEvent('STATUS_UPDATED', orderId, sbOrder.customerId, sbOrder.restaurantId, payload);
          return {
            id: sbOrder.id,
            userId: sbOrder.customerId,
            targetRestaurantId: sbOrder.restaurantId,
            status: 'Cancelled',
            dishName: sbOrder.items?.[0]?.itemNameSnapshot || 'Order',
            budgetTzs: sbOrder.totalTzs,
            servingsCount: '1',
            diningOption: sbOrder.fulfillmentType as any,
            specialInstructions: sbOrder.specialInstructions || '',
            paymentStatus: sbOrder.paymentStatus === 'SUCCESS' ? 'PAID' : 'UNPAID',
            orderNumber: sbOrder.orderNumber,
          } as any;
        }
      }
      throw new Error(`Order ${orderId} not found`);
    }

    const updated = await MloHubDB.customOrders.update(orderId, {
      status: 'Cancelled',
      statusMessageEn: `Order could not be fulfilled: ${reason}.`,
      statusMessageSw: `Agizo halikuweza kupikwa: ${reason}.`,
    });

    if (!updated) throw new Error('Failed to reject order');

    // Customer Notification
    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'order',
      titleEn: `Order #${existing.orderNumber} Cancelled`,
      titleSw: `Agizo #${existing.orderNumber} Limesitishwa`,
      messageEn: `Reason: ${reason}. Any pre-authorized payment is immediately refunded.`,
      messageSw: `Sababu: ${reason}. Malipo yoyote yaliyofanyika yanarudishwa mara moja.`,
      data: { orderId, reason },
    });

    const payload = { order: updated, reason, status: 'Cancelled' };
    this.broadcastOrderEvent('STATUS_UPDATED', orderId, existing.userId, existing.targetRestaurantId || '', payload);

    return updated;
  }

  /**
   * 5. Update kitchen fulfillment status (Cooking ➔ Ready ➔ Completed)
   */
  async updateFulfillmentStatus(
    orderId: string,
    status: 'Cooking' | 'Ready' | 'Completed' | 'Cancelled',
    customMessageEn?: string,
    customMessageSw?: string
  ): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    if (isSupabaseConfigured()) {
      try {
        let repoStatus: 'PREPARING' | 'READY' | 'COMPLETED' | 'CANCELLED' = 'PREPARING';
        if (status === 'Cooking') repoStatus = 'PREPARING';
        else if (status === 'Ready') repoStatus = 'READY';
        else if (status === 'Completed') repoStatus = 'COMPLETED';
        else if (status === 'Cancelled') repoStatus = 'CANCELLED';
        await OrderRepository.updateStatus(orderId, repoStatus);
      } catch (err) {
        // Not in Supabase orders table or already updated
      }
    }

    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) {
      if (isSupabaseConfigured()) {
        const sbOrder = await OrderRepository.getOrderById(orderId);
        if (sbOrder) {
          const payload = { order: sbOrder, status };
          this.broadcastOrderEvent('STATUS_UPDATED', orderId, sbOrder.customerId, sbOrder.restaurantId, payload);
          return {
            id: sbOrder.id,
            userId: sbOrder.customerId,
            targetRestaurantId: sbOrder.restaurantId,
            status,
            dishName: sbOrder.items?.[0]?.itemNameSnapshot || 'Order',
            budgetTzs: sbOrder.totalTzs,
            servingsCount: '1',
            diningOption: sbOrder.fulfillmentType as any,
            specialInstructions: sbOrder.specialInstructions || '',
            paymentStatus: sbOrder.paymentStatus === 'SUCCESS' ? 'PAID' : 'UNPAID',
            orderNumber: sbOrder.orderNumber,
          } as any;
        }
      }
      throw new Error(`Order with ID ${orderId} not found.`);
    }

    let defaultEn = `Order status: ${status}`;
    let defaultSw = `Hali ya agizo: ${status}`;

    if (status === 'Cooking') {
      defaultEn = 'Chef is simmering spices and packaging fresh servings.';
      defaultSw = 'Mpishi anaendelea kupika na kuandaa vifungashio safi.';
    } else if (status === 'Ready') {
      defaultEn = 'Packed with tamper-evident seal. Ready for pickup or courier dispatch!';
      defaultSw = 'Limefungwa kwa usalama. Tayari kwa kuchukuliwa au dereva!';
    } else if (status === 'Completed') {
      defaultEn = 'Delivered & Completed! Thank you for dining with MloHub.';
      defaultSw = 'Limepokelewa na kukamilika! Asante kwa kuchagua MloHub.';
    }

    const updated = await MloHubDB.customOrders.update(orderId, {
      status,
      statusMessageEn: customMessageEn || defaultEn,
      statusMessageSw: customMessageSw || defaultSw,
    });

    if (!updated) throw new Error('Failed to update order status');

    // Create Notification
    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'order',
      titleEn: `Order #${existing.orderNumber}: ${status}`,
      titleSw: `Agizo #${existing.orderNumber}: ${status}`,
      messageEn: customMessageEn || defaultEn,
      messageSw: customMessageSw || defaultSw,
      data: { orderId, status },
    });

    // Realtime Dispatch (Customer, Restaurant, Admin)
    const payload = { order: updated, status };
    this.broadcastOrderEvent('STATUS_UPDATED', orderId, existing.userId, existing.targetRestaurantId || '', payload);

    return updated;
  }

  /**
   * 6. Dispatch restaurant delivery rider
   */
  async dispatchOrderWithRider(
    orderId: string,
    riderName: string,
    riderPhone: string
  ): Promise<CustomMealRequestEntity> {
    await MloHubDB.init();
    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) throw new Error(`Order #${orderId} haikupatikana.`);

    const pin = existing.deliveryPin || '1234';

    const updated = await MloHubDB.customOrders.update(orderId, {
      status: 'Out for Delivery',
      riderName,
      riderPhone,
      dispatchedAt: new Date().toISOString(),
      statusMessageEn: `Out for delivery with ${riderName} (${riderPhone}). Provide PIN [ ${pin} ] upon delivery.`,
      statusMessageSw: `Chakula kipo njiani kinaletwa na ${riderName} (${riderPhone}). Mpe dereva PIN [ ${pin} ] akifika.`,
    });

    if (!updated) throw new Error('Failed to dispatch order with rider');

    // Customer Notification
    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'delivery_dispatched',
      titleEn: `Chakula Kipo Njiani! PIN: ${pin}`,
      titleSw: `Chakula Kipo Njiani! PIN: ${pin}`,
      messageEn: `Rider ${riderName} (${riderPhone}) is heading your way. Give them PIN [ ${pin} ] to receive food.`,
      messageSw: `Dereva ${riderName} (${riderPhone}) yupo njiani. Mpe PIN [ ${pin} ] atakapokukabidhi chakula.`,
      data: { orderId, pin, riderName, riderPhone },
    });

    const payload = {
      order: updated,
      status: 'Out for Delivery',
      riderName,
      riderPhone,
      pin,
    };

    this.broadcastOrderEvent('STATUS_UPDATED', orderId, existing.userId, existing.targetRestaurantId || '', payload);

    return updated;
  }

  /**
   * 7. Verify 4-Digit Delivery PIN upon delivery handoff
   */
  async verifyAndCompleteDelivery(
    orderId: string,
    inputPin: string
  ): Promise<{ success: boolean; message: string; order: CustomMealRequestEntity }> {
    await MloHubDB.init();
    const existing = MloHubDB.customOrders.getById(orderId);
    if (!existing) throw new Error(`Order #${orderId} haikupatikana.`);

    const targetPin = (existing.deliveryPin || '1234').trim();
    const cleanedInput = inputPin.trim();

    if (cleanedInput !== targetPin) {
      throw new Error(`PIN siyo sahihi! Tafadhali muulize mteja namba ya uthibitisho (PIN: ${targetPin.slice(0, 1)}***).`);
    }

    const updated = await MloHubDB.customOrders.update(orderId, {
      status: 'Completed',
      deliveredAt: new Date().toISOString(),
      statusMessageEn: 'Delivered & Completed! Handoff verified successfully.',
      statusMessageSw: 'Chakula kimekabidhiwa salama! Uthibitisho wa PIN umekamilika.',
    });

    if (!updated) throw new Error('Failed to complete delivery');

    // Final Customer Notification
    await MloHubDB.notifications.create({
      userId: existing.userId,
      type: 'order_completed',
      titleEn: 'Order Delivered! Bon Appétit!',
      titleSw: 'Chakula Kimefika! Karibu Chakula!',
      messageEn: `Your order from ${existing.restaurantName} has been delivered successfully. Thank you!`,
      messageSw: `Agizo lako kutoka ${existing.restaurantName} limekabidhiwa salama. Asante kwa kuchagua MloHub!`,
      data: { orderId },
    });

    const payload = {
      order: updated,
      status: 'Completed',
    };

    this.broadcastOrderEvent('STATUS_UPDATED', orderId, existing.userId, existing.targetRestaurantId || '', payload);

    return {
      success: true,
      message: 'Uthibitisho umefanikiwa! Oda imekamilika.',
      order: updated,
    };
  }

  /**
   * Helper: Subscribe to incoming restaurant orders
   */
  subscribeToRestaurantOrders(
    restaurantId: string,
    callback: (event: RealtimeEventPayload) => void
  ): () => void {
    const unsub1 = RealtimeEventEngine.subscribe(`orders:restaurant:${restaurantId}`, callback);
    const unsub2 = RealtimeEventEngine.subscribe('custom_meals:broadcast', callback);
    return () => {
      unsub1();
      unsub2();
    };
  }

  /**
   * Helper: Subscribe to customer order updates
   */
  subscribeToCustomerOrders(
    customerId: string,
    callback: (event: RealtimeEventPayload) => void
  ): () => void {
    return RealtimeEventEngine.subscribe(`orders:customer:${customerId}`, callback);
  }
}

export const OrderPipelineService = new OrderPipelineServiceImpl();
