import { UserRole } from '../db/types';

// ============================================================================
// 1. RESTAURANT & MULTI-BRANCH DOMAIN MODELS
// ============================================================================

export type SellerTier = 'BASIC_SELLER' | 'VERIFIED_SELLER';
export type VerificationStatus = 'PENDING_VERIFICATION' | 'VERIFIED' | 'REJECTED' | 'SUSPENDED';

export interface Restaurant {
  id: string;
  ownerId?: string;
  name: string;
  slug: string;
  cuisine: string;
  description?: string;
  sellerTier: SellerTier;
  rating: number;
  reviewsCount: number;
  minPriceTzs: number;
  maxPriceTzs: number;
  address: string;
  neighborhood: string;
  regionCity: string;
  distanceKm: number;
  estimatedPrepTimeMinutes: number;
  isOpen: boolean;
  isVerified: boolean;
  verificationStatus: VerificationStatus;
  tinNumber?: string;
  businessLicenseNumber?: string;
  payoutPhoneNumber?: string;
  payoutProvider?: string;
  openingHours?: string;
  closingHours?: string;
  logoUrl?: string;
  coverImageUrl?: string;
  foodSpotPhotos?: string[];
  specialty?: string;
  specialistBadge?: string;
  specialistCategory?: string;
  emoji?: string;
  tags?: string[];
  lat?: number;
  lng?: number;
  supportsOrderAhead: boolean;
  menu?: MenuItem[];
  branches?: RestaurantBranch[];
  createdAt: string;
  updatedAt: string;
}

export interface RestaurantBranch {
  id: string;
  restaurantId: string;
  name: string;
  address: string;
  region: string;
  district?: string;
  ward?: string;
  latitude?: number;
  longitude?: number;
  phone: string;
  openingHours?: Record<string, any>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type PlatformRole = 'CUSTOMER' | 'RESTAURANT' | 'ADMIN' | 'SUPER_ADMIN';
export type RestaurantRole = 'OWNER' | 'MANAGER' | 'CHEF' | 'STAFF';

export type RestaurantPermission =
  | 'VIEW_DASHBOARD'
  | 'VIEW_ORDERS'
  | 'MANAGE_ORDERS'
  | 'VIEW_MENU'
  | 'MANAGE_MENU'
  | 'VERIFY_MENU'
  | 'VIEW_RESERVATIONS'
  | 'MANAGE_RESERVATIONS'
  | 'VIEW_REVIEWS'
  | 'VIEW_ANALYTICS'
  | 'VIEW_EARNINGS'
  | 'MANAGE_STAFF'
  | 'MANAGE_RESTAURANT';

export interface RestaurantMember {
  id: string;
  userId: string;
  restaurantId: string;
  role: RestaurantRole;
  permissions: RestaurantPermission[] | string[];
  isPrimaryOwner: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface RestaurantApplication {
  id: string;
  applicantUserId?: string;
  businessName: string;
  ownerName: string;
  ownerPhone: string;
  ownerEmail?: string;
  cuisineType: string;
  neighborhood: string;
  address: string;
  businessType?: string;
  hasTinOrLicense: boolean;
  tinNumber?: string;
  licenseNumber?: string;
  status: 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  notes?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================================================
// 2. MENU & FRESHNESS DOMAIN MODELS
// ============================================================================

export interface MenuCategory {
  id: string;
  restaurantId: string;
  nameEn: string;
  nameSw: string;
  description?: string;
  displayOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  categoryId?: string;
  name: string;
  nameEn?: string;
  nameSw?: string;
  description?: string;
  descriptionEn?: string;
  descriptionSw?: string;
  basePrice: number;
  priceTzs: number;
  currency: string;
  photoUrl?: string;
  imageUrl?: string;
  stockQuantity?: number;
  isAvailable: boolean;
  isArchived?: boolean;
  preparationMinutes?: number;
  dietaryTags?: string[];
  spiceLevel?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BranchMenuItem {
  id: string;
  branchId: string;
  menuItemId: string;
  price: number;
  isAvailable: boolean;
  stockStatus: 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK';
  lastPriceVerifiedAt?: string;
  lastAvailabilityVerifiedAt?: string;
  updatedAt: string;
}

export type VerificationType = 'MENU' | 'PRICE' | 'AVAILABILITY' | 'HOURS';
export type VerificationSource = 'RESTAURANT' | 'ADMIN' | 'CUSTOMER_REPORT' | 'SYSTEM';

export interface MenuVerification {
  id: string;
  restaurantId: string;
  branchId?: string;
  menuItemId?: string;
  verificationType: VerificationType;
  verifiedBy: string;
  verificationSource: VerificationSource;
  previousValue?: Record<string, any>;
  verifiedValue?: Record<string, any>;
  createdAt: string;
}

// ============================================================================
// 3. ORDERS & COMMERCE DOMAIN MODELS
// ============================================================================

export type OrderStatus =
  | 'PENDING'
  | 'ACCEPTED'
  | 'PREPARING'
  | 'READY'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'REJECTED';

export type PaymentStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'SUCCESS'
  | 'FAILED'
  | 'CANCELLED'
  | 'REFUNDED';

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  restaurantId: string;
  restaurantName?: string;
  branchId?: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  subtotalTzs: number;
  serviceFeeTzs: number;
  deliveryFeeTzs: number;
  totalTzs: number;
  currency: string;
  fulfillmentType: 'Delivery' | 'Dine-In' | 'Takeaway';
  deliveryAddress?: string;
  specialInstructions?: string;
  estimatedPrepMinutes?: number;
  acceptedAt?: string;
  readyAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
  items?: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export type OrderEntity = Order;

export interface OrderItem {
  id: string;
  orderId: string;
  menuItemId?: string;
  itemNameSnapshot: string;
  priceSnapshot: number;
  quantity: number;
  subtotal: number;
  specialNotes?: string;
  createdAt: string;
}

export type ReservationStatus = 'PENDING' | 'CONFIRMED' | 'SEATED' | 'CANCELLED' | 'NO_SHOW';

export interface Reservation {
  id: string;
  customerId: string;
  restaurantId: string;
  restaurantName?: string;
  branchId?: string;
  partySize: number;
  reservationDate: string;
  reservationTime: string;
  status: ReservationStatus;
  customerNote?: string;
  restaurantNote?: string;
  depositOption?: 'deposit_50' | 'full_100';
  depositAmountTzs?: number;
  totalBillTzs?: number;
  remainingBalanceTzs?: number;
  isDepositPaid?: boolean;
  paymentId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomMealRequest {
  id: string;
  orderNumber: string;
  customerId: string;
  title: string;
  dishName: string;
  description?: string;
  specialInstructions?: string;
  budgetMin?: number;
  budgetMax?: number;
  budgetTzs: number;
  servings: string;
  servingsCount: string;
  diningOption: 'Delivery' | 'Dine-In' | 'Takeaway';
  desiredDate?: string;
  preferredTime?: string;
  location?: string;
  deliveryLocation?: string;
  status: OrderStatus;
  statusMessageEn?: string;
  statusMessageSw?: string;
  acceptedQuoteId?: string;
  quotes?: RestaurantQuote[];
  createdAt: string;
  updatedAt: string;
}

export interface RestaurantQuote {
  id: string;
  requestId: string;
  restaurantId: string;
  restaurantName?: string;
  amountTzs: number;
  quotedPriceTzs: number;
  estimatedPrepMinutes: number;
  message?: string;
  chefNotes?: string;
  status: 'OFFERED' | 'ACCEPTED' | 'REJECTED' | 'EXPIRED';
  createdAt: string;
}

// ============================================================================
// 4. PAYMENTS, REVIEWS & NOTIFICATIONS DOMAIN MODELS
// ============================================================================

export interface Payment {
  id: string;
  orderId?: string;
  reservationId?: string;
  customerId: string;
  restaurantId?: string;
  provider: string;
  externalReference?: string;
  providerTransactionId?: string;
  amountTzs: number;
  platformCommissionTzs: number;
  netRestaurantPayoutTzs: number;
  currency: string;
  paymentMethod: string;
  phoneNumber: string;
  status: PaymentStatus;
  idempotencyKey?: string;
  webhookVerified: boolean;
  paidAt?: string;
  refundedAt?: string;
  metadata?: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: string;
  category: 'ORDER' | 'PAYMENT' | 'SYSTEM' | 'RESTAURANT' | 'QUOTE';
  titleEn: string;
  titleSw: string;
  messageEn: string;
  messageSw: string;
  isRead: boolean;
  orderId?: string;
  restaurantId?: string;
  actionType?: string;
  payload?: Record<string, any>;
  createdAt: string;
}

export interface Review {
  id: string;
  customerId: string;
  restaurantId: string;
  orderId?: string;
  overallRating: number;
  foodRating?: number;
  valueRating?: number;
  serviceRating?: number;
  atmosphereRating?: number;
  comment?: string;
  status: 'PUBLISHED' | 'FLAGGED' | 'HIDDEN';
  createdAt: string;
  updatedAt?: string;
}

export interface AuditLog {
  id: string;
  actorUserId: string;
  adminName?: string;
  action: string;
  entityType: string;
  entityId: string;
  metadata?: Record<string, any>;
  ipAddress?: string;
  createdAt: string;
}

export type DataReportType =
  | 'WRONG_PRICE'
  | 'ITEM_UNAVAILABLE'
  | 'WRONG_HOURS'
  | 'WRONG_LOCATION'
  | 'RESTAURANT_CLOSED'
  | 'OTHER';

export type DataReportStatus = 'OPEN' | 'INVESTIGATING' | 'RESOLVED' | 'REJECTED';

export interface DataReport {
  id: string;
  reporterUserId: string;
  reporterName?: string;
  restaurantId: string;
  restaurantName?: string;
  branchId?: string;
  menuItemId?: string;
  menuItemName?: string;
  reportType: DataReportType;
  message: string;
  reportedValue?: string;
  catalogValue?: string;
  status: DataReportStatus;
  reviewedBy?: string;
  reviewedAt?: string;
  resolutionNotes?: string;
  createdAt: string;
}

